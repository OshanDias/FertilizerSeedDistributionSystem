-- Create Database
DROP DATABASE IF EXISTS fertilizer_seed_distribution_db;
CREATE DATABASE fertilizer_seed_distribution_db;
USE fertilizer_seed_distribution_db;

-- Table 1: Fertilizer Suppliers
CREATE TABLE fertilizer_suppliers (
    supplier_id INT PRIMARY KEY AUTO_INCREMENT,
    company_name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15) NOT NULL,
    address TEXT,
    city VARCHAR(50),
    country VARCHAR(50) DEFAULT 'Sri Lanka',
    business_type ENUM('Manufacturer', 'Distributor', 'Importer', 'Local Producer') NOT NULL,
    license_number VARCHAR(50) UNIQUE NOT NULL,
    rating DECIMAL(2,1) DEFAULT 0.0 COMMENT 'Rating out of 5.0',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table 2: Products (Fertilizers & Seeds)
CREATE TABLE products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    supplier_id INT NOT NULL,
    product_name VARCHAR(100) NOT NULL,
    product_type ENUM('Fertilizer', 'Seed', 'Pesticide', 'Growth Supplement') NOT NULL,
    category VARCHAR(50) COMMENT 'e.g., Organic, Chemical, Hybrid, etc.',
    crop_type VARCHAR(50) COMMENT 'Suitable for which crop',
    unit_type ENUM('KG', 'Liter', 'Pack', 'Bag') NOT NULL,
    price_per_unit DECIMAL(10,2) NOT NULL,
    stock_quantity INT DEFAULT 0,
    reorder_level INT DEFAULT 50 COMMENT 'Minimum stock before reorder',
    expiry_date DATE,
    manufacturer VARCHAR(100),
    description TEXT,
    status ENUM('AVAILABLE', 'LOW_STOCK', 'OUT_OF_STOCK', 'DISCONTINUED') DEFAULT 'AVAILABLE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (supplier_id) REFERENCES fertilizer_suppliers(supplier_id) ON DELETE CASCADE
);

-- Table 3: Retail Customers
CREATE TABLE retail_customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15) NOT NULL,
    nic VARCHAR(20) UNIQUE NOT NULL,
    address TEXT,
    city VARCHAR(50),
    customer_type ENUM('Farmer', 'Retailer', 'Wholesaler', 'Individual') NOT NULL,
    farm_size DECIMAL(10,2) COMMENT 'Farm size in acres (for farmers)',
    business_name VARCHAR(100) COMMENT 'Business name (for retailers/wholesalers)',
    loyalty_points INT DEFAULT 0,
    total_purchases DECIMAL(12,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table 4: Sales Orders (MAIN TRANSACTION TABLE)
CREATE TABLE sales_orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT NOT NULL,
    product_id INT NOT NULL,
    order_date DATE NOT NULL,
    delivery_date DATE,
    quantity INT NOT NULL,
    unit_type VARCHAR(20),
    price_per_unit DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    discount_percent DECIMAL(5,2) DEFAULT 0.00,
    discount_amount DECIMAL(10,2) DEFAULT 0.00,
    total_amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('Cash', 'Card', 'Bank Transfer', 'Credit') DEFAULT 'Cash',
    payment_status ENUM('PENDING', 'PAID', 'PARTIAL', 'REFUNDED') DEFAULT 'PENDING',
    delivery_status ENUM('PROCESSING', 'READY', 'DISPATCHED', 'DELIVERED', 'CANCELLED') DEFAULT 'PROCESSING',
    delivery_address TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES retail_customers(customer_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE
);

-- Insert Sample Suppliers
INSERT INTO fertilizer_suppliers (company_name, contact_person, email, phone, address, city, business_type, license_number, rating) VALUES
('Lanka Fertilizer Company', 'Sunil Perera', 'sunil@lankafertilizer.lk', '0112345678', 'No. 123, Industrial Zone, Ekala', 'Colombo', 'Manufacturer', 'LIC-LFC-001', 4.7),
('Green Agro Supplies', 'Nimal Silva', 'nimal@greenagro.lk', '0332234567', 'No. 45, Main Street, Kurunegala', 'Kurunegala', 'Distributor', 'LIC-GAS-002', 4.5),
('Ceylon Seed Corporation', 'Kamala Fernando', 'kamala@ceylonseed.lk', '0812223344', 'No. 67, Seed Lane, Anuradhapura', 'Anuradhapura', 'Local Producer', 'LIC-CSC-003', 4.8),
('Tropical Growth Solutions', 'Rohan Jayasinghe', 'rohan@tropicalgrowth.lk', '0372234455', 'No. 89, Export Zone, Galle', 'Galle', 'Importer', 'LIC-TGS-004', 4.4),
('Prime Agriculture Inputs', 'Shanika Bandara', 'shanika@primeagri.lk', '0252223366', 'No. 34, Agro Park, Matara', 'Matara', 'Distributor', 'LIC-PAI-005', 4.6);

-- Insert Sample Products (Fertilizers)
INSERT INTO products (supplier_id, product_name, product_type, category, crop_type, unit_type, price_per_unit, stock_quantity, reorder_level, expiry_date, manufacturer, description, status) VALUES
(1, 'Urea Fertilizer 50kg', 'Fertilizer', 'Chemical', 'Rice, Vegetables', 'Bag', 4500.00, 500, 100, '2027-12-31', 'Lanka Fertilizer Company', 'High nitrogen content fertilizer', 'AVAILABLE'),
(1, 'NPK 15-15-15 Fertilizer', 'Fertilizer', 'Chemical', 'All Crops', 'Bag', 5200.00, 350, 80, '2027-10-31', 'Lanka Fertilizer Company', 'Balanced NPK fertilizer', 'AVAILABLE'),
(2, 'Organic Compost 25kg', 'Fertilizer', 'Organic', 'Vegetables, Fruits', 'Bag', 1800.00, 800, 150, NULL, 'Green Agro Supplies', 'Natural organic fertilizer', 'AVAILABLE'),
(4, 'Potash Fertilizer', 'Fertilizer', 'Chemical', 'Root Crops', 'KG', 95.00, 1200, 200, '2028-06-30', 'Tropical Growth Solutions', 'Potassium-rich fertilizer', 'AVAILABLE'),
(5, 'Bio Fertilizer Liquid', 'Fertilizer', 'Organic', 'All Crops', 'Liter', 850.00, 250, 50, '2026-08-31', 'Prime Agriculture Inputs', 'Microbial fertilizer solution', 'AVAILABLE'),

-- Insert Sample Products (Seeds)
(3, 'BG 352 Rice Seeds', 'Seed', 'Hybrid', 'Rice', 'KG', 320.00, 600, 100, '2026-12-31', 'Ceylon Seed Corporation', 'High-yield rice variety', 'AVAILABLE'),
(3, 'Carrot Seeds F1 Hybrid', 'Seed', 'Hybrid', 'Vegetables', 'Pack', 450.00, 400, 80, '2027-03-31', 'Ceylon Seed Corporation', 'Premium carrot seeds', 'AVAILABLE'),
(3, 'Tomato Seeds Premium', 'Seed', 'Hybrid', 'Vegetables', 'Pack', 380.00, 550, 100, '2027-01-31', 'Ceylon Seed Corporation', 'Disease-resistant tomato variety', 'AVAILABLE'),
(2, 'Chili Seeds Local', 'Seed', 'Open Pollinated', 'Vegetables', 'KG', 1200.00, 200, 50, '2026-11-30', 'Green Agro Supplies', 'Traditional chili variety', 'AVAILABLE'),
(4, 'Maize Seeds Hybrid', 'Seed', 'Hybrid', 'Corn', 'KG', 680.00, 450, 100, '2027-04-30', 'Tropical Growth Solutions', 'High-yield corn seeds', 'AVAILABLE'),

-- Insert Sample Products (Pesticides & Supplements)
(4, 'Insecticide Spray 500ml', 'Pesticide', 'Chemical', 'All Crops', 'Liter', 1250.00, 300, 60, '2027-09-30', 'Tropical Growth Solutions', 'Broad-spectrum insecticide', 'AVAILABLE'),
(5, 'Growth Booster Pro', 'Growth Supplement', 'Organic', 'Fruits, Vegetables', 'Liter', 950.00, 180, 40, '2027-05-31', 'Prime Agriculture Inputs', 'Plant growth enhancer', 'AVAILABLE');

-- Insert Sample Customers
INSERT INTO retail_customers (first_name, last_name, email, phone, nic, address, city, customer_type, farm_size, business_name, loyalty_points, total_purchases) VALUES
('Anura', 'Bandara', 'anura.bandara@farm.lk', '0771234567', '892345678V', 'No. 23, Farm Road, Polonnaruwa', 'Polonnaruwa', 'Farmer', 15.5, NULL, 450, 125000.00),
('Niluka', 'Perera', 'niluka.perera@retail.lk', '0712345678', '915432109V', 'No. 67, Market Street, Kandy', 'Kandy', 'Retailer', NULL, 'Niluka Agro Center', 820, 285000.00),
('Pradeep', 'Silva', 'pradeep.silva@farm.lk', '0763456789', '872345678V', 'No. 45, Village Lane, Matara', 'Matara', 'Farmer', 25.0, NULL, 320, 98000.00),
('Kamani', 'Fernando', 'kamani.fernando@wholesale.lk', '0724567890', '905432109V', 'No. 89, Wholesale Complex, Gampaha', 'Gampaha', 'Wholesaler', NULL, 'Kamani Agro Traders', 1250, 450000.00),
('Ranjith', 'Jayawardena', 'ranjith.j@individual.lk', '0775678901', '883456789V', 'No. 12, Home Garden, Kurunegala', 'Kurunegala', 'Individual', 2.5, NULL, 85, 45000.00);

-- Insert Sample Orders
INSERT INTO sales_orders (customer_id, product_id, order_date, delivery_date, quantity, unit_type, price_per_unit, subtotal, discount_percent, discount_amount, total_amount, payment_method, payment_status, delivery_status, delivery_address, notes) VALUES
(1, 1, '2026-01-15', '2026-01-20', 10, 'Bag', 4500.00, 45000.00, 5.00, 2250.00, 42750.00, 'Bank Transfer', 'PAID', 'DELIVERED', 'Same as customer address', 'Bulk order - farmer discount applied'),
(2, 6, '2026-01-18', '2026-01-22', 50, 'KG', 320.00, 16000.00, 8.00, 1280.00, 14720.00, 'Cash', 'PAID', 'DELIVERED', 'Niluka Agro Center, Kandy', 'Retailer bulk purchase'),
(3, 3, '2026-01-20', '2026-01-25', 5, 'Bag', 1800.00, 9000.00, 0.00, 0.00, 9000.00, 'Cash', 'PAID', 'DELIVERED', 'Same as customer address', 'Organic farming requirement'),
(4, 2, '2026-01-22', '2026-01-27', 100, 'Bag', 5200.00, 520000.00, 12.00, 62400.00, 457600.00, 'Bank Transfer', 'PAID', 'DISPATCHED', 'Kamani Agro Traders Warehouse', 'Wholesaler mega order'),
(5, 7, '2026-01-25', '2026-01-30', 3, 'Pack', 450.00, 1350.00, 0.00, 0.00, 1350.00, 'Card', 'PAID', 'READY', 'Home delivery, Kurunegala', 'Home gardening project'),
(1, 4, '2026-01-28', '2026-02-02', 20, 'KG', 95.00, 1900.00, 5.00, 95.00, 1805.00, 'Cash', 'PENDING', 'PROCESSING', 'Same as customer address', 'For potato cultivation'),
(2, 10, '2026-01-30', '2026-02-05', 15, 'KG', 680.00, 10200.00, 8.00, 816.00, 9384.00, 'Credit', 'PARTIAL', 'PROCESSING', 'Niluka Agro Center, Kandy', 'Partial payment received');

-- Display success message
SELECT 'Database created successfully!' AS Status;
SELECT 'Tables: fertilizer_suppliers, products, retail_customers, sales_orders' AS Info;
SELECT COUNT(*) AS Total_Suppliers FROM fertilizer_suppliers;
SELECT COUNT(*) AS Total_Products FROM products;
SELECT COUNT(*) AS Total_Customers FROM retail_customers;
SELECT COUNT(*) AS Total_Orders FROM sales_orders;