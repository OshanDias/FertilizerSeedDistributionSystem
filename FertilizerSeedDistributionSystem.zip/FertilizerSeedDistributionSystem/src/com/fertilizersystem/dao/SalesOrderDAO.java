package com.fertilizersystem.dao;

import com.fertilizersystem.model.SalesOrder;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SalesOrderDAO {
    
    private Connection connection;
    
    public SalesOrderDAO() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }
    
    // CREATE
    public boolean addOrder(SalesOrder order) throws SQLException {
        String query = "INSERT INTO sales_orders (customer_id, product_id, order_date, delivery_date, " +
                       "quantity, unit_type, price_per_unit, subtotal, discount_percent, " +
                       "discount_amount, total_amount, payment_method, payment_status, " +
                       "delivery_status, delivery_address, notes) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, order.getCustomerId());
            pstmt.setInt(2, order.getProductId());
            pstmt.setDate(3, order.getOrderDate());
            pstmt.setDate(4, order.getDeliveryDate());
            pstmt.setInt(5, order.getQuantity());
            pstmt.setString(6, order.getUnitType());
            pstmt.setDouble(7, order.getPricePerUnit());
            pstmt.setDouble(8, order.getSubtotal());
            pstmt.setDouble(9, order.getDiscountPercent());
            pstmt.setDouble(10, order.getDiscountAmount());
            pstmt.setDouble(11, order.getTotalAmount());
            pstmt.setString(12, order.getPaymentMethod());
            pstmt.setString(13, order.getPaymentStatus());
            pstmt.setString(14, order.getDeliveryStatus());
            pstmt.setString(15, order.getDeliveryAddress());
            pstmt.setString(16, order.getNotes());
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // READ
    public SalesOrder getOrderById(int orderId) throws SQLException {
        String query = "SELECT o.*, " +
                       "CONCAT(c.first_name, ' ', c.last_name) as customer_name, " +
                       "c.phone as customer_phone, " +
                       "p.product_name, " +
                       "p.product_type " +
                       "FROM sales_orders o " +
                       "JOIN retail_customers c ON o.customer_id = c.customer_id " +
                       "JOIN products p ON o.product_id = p.product_id " +
                       "WHERE o.order_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, orderId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractOrderFromResultSet(rs);
            }
        }
        return null;
    }
    
    // READ ALL
    public List<SalesOrder> getAllOrders() throws SQLException {
        List<SalesOrder> orders = new ArrayList<>();
        String query = "SELECT o.*, " +
                       "CONCAT(c.first_name, ' ', c.last_name) as customer_name, " +
                       "c.phone as customer_phone, " +
                       "p.product_name, " +
                       "p.product_type " +
                       "FROM sales_orders o " +
                       "JOIN retail_customers c ON o.customer_id = c.customer_id " +
                       "JOIN products p ON o.product_id = p.product_id " +
                       "ORDER BY o.order_id DESC";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                orders.add(extractOrderFromResultSet(rs));
            }
        }
        return orders;
    }
    
    // READ BY STATUS
    public List<SalesOrder> getOrdersByStatus(String deliveryStatus) throws SQLException {
        List<SalesOrder> orders = new ArrayList<>();
        String query = "SELECT o.*, " +
                       "CONCAT(c.first_name, ' ', c.last_name) as customer_name, " +
                       "c.phone as customer_phone, " +
                       "p.product_name, " +
                       "p.product_type " +
                       "FROM sales_orders o " +
                       "JOIN retail_customers c ON o.customer_id = c.customer_id " +
                       "JOIN products p ON o.product_id = p.product_id " +
                       "WHERE o.delivery_status = ? " +
                       "ORDER BY o.delivery_date";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, deliveryStatus);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                orders.add(extractOrderFromResultSet(rs));
            }
        }
        return orders;
    }
    
    // READ PROCESSING ORDERS
    public List<SalesOrder> getProcessingOrders() throws SQLException {
        return getOrdersByStatus("PROCESSING");
    }
    
    // UPDATE
    public boolean updateOrder(SalesOrder order) throws SQLException {
        String query = "UPDATE sales_orders SET customer_id=?, product_id=?, order_date=?, " +
                       "delivery_date=?, quantity=?, unit_type=?, price_per_unit=?, subtotal=?, " +
                       "discount_percent=?, discount_amount=?, total_amount=?, payment_method=?, " +
                       "payment_status=?, delivery_status=?, delivery_address=?, notes=? " +
                       "WHERE order_id=?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, order.getCustomerId());
            pstmt.setInt(2, order.getProductId());
            pstmt.setDate(3, order.getOrderDate());
            pstmt.setDate(4, order.getDeliveryDate());
            pstmt.setInt(5, order.getQuantity());
            pstmt.setString(6, order.getUnitType());
            pstmt.setDouble(7, order.getPricePerUnit());
            pstmt.setDouble(8, order.getSubtotal());
            pstmt.setDouble(9, order.getDiscountPercent());
            pstmt.setDouble(10, order.getDiscountAmount());
            pstmt.setDouble(11, order.getTotalAmount());
            pstmt.setString(12, order.getPaymentMethod());
            pstmt.setString(13, order.getPaymentStatus());
            pstmt.setString(14, order.getDeliveryStatus());
            pstmt.setString(15, order.getDeliveryAddress());
            pstmt.setString(16, order.getNotes());
            pstmt.setInt(17, order.getOrderId());
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // UPDATE DELIVERY STATUS
    public boolean updateDeliveryStatus(int orderId, String newStatus) throws SQLException {
        String query = "UPDATE sales_orders SET delivery_status = ? WHERE order_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, newStatus);
            pstmt.setInt(2, orderId);
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // UPDATE PAYMENT STATUS
    public boolean updatePaymentStatus(int orderId, String newStatus) throws SQLException {
        String query = "UPDATE sales_orders SET payment_status = ? WHERE order_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, newStatus);
            pstmt.setInt(2, orderId);
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // DELETE
    public boolean deleteOrder(int orderId) throws SQLException {
        String query = "DELETE FROM sales_orders WHERE order_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, orderId);
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // STATISTICS - Get total sales
    public double getTotalSales() throws SQLException {
        String query = "SELECT SUM(total_amount) as total FROM sales_orders " +
                       "WHERE delivery_status = 'DELIVERED'";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            if (rs.next()) {
                return rs.getDouble("total");
            }
        }
        return 0.0;
    }
    
    // STATISTICS - Get order count by status
    public int getOrderCountByStatus(String status) throws SQLException {
        String query = "SELECT COUNT(*) FROM sales_orders WHERE delivery_status = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, status);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }
    
    // Helper method
    private SalesOrder extractOrderFromResultSet(ResultSet rs) throws SQLException {
        SalesOrder order = new SalesOrder();
        order.setOrderId(rs.getInt("order_id"));
        order.setCustomerId(rs.getInt("customer_id"));
        order.setProductId(rs.getInt("product_id"));
        order.setOrderDate(rs.getDate("order_date"));
        order.setDeliveryDate(rs.getDate("delivery_date"));
        order.setQuantity(rs.getInt("quantity"));
        order.setUnitType(rs.getString("unit_type"));
        order.setPricePerUnit(rs.getDouble("price_per_unit"));
        order.setSubtotal(rs.getDouble("subtotal"));
        order.setDiscountPercent(rs.getDouble("discount_percent"));
        order.setDiscountAmount(rs.getDouble("discount_amount"));
        order.setTotalAmount(rs.getDouble("total_amount"));
        order.setPaymentMethod(rs.getString("payment_method"));
        order.setPaymentStatus(rs.getString("payment_status"));
        order.setDeliveryStatus(rs.getString("delivery_status"));
        order.setDeliveryAddress(rs.getString("delivery_address"));
        order.setNotes(rs.getString("notes"));
        order.setCreatedAt(rs.getTimestamp("created_at"));
        
        // From JOINs
        order.setCustomerName(rs.getString("customer_name"));
        order.setCustomerPhone(rs.getString("customer_phone"));
        order.setProductName(rs.getString("product_name"));
        order.setProductType(rs.getString("product_type"));
        
        return order;
    }
}