package com.fertilizersystem.dao;

import com.fertilizersystem.model.Product;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
    
    private Connection connection;
    
    public ProductDAO() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }
    
    // CREATE
    public boolean addProduct(Product product) throws SQLException {
        String query = "INSERT INTO products (supplier_id, product_name, product_type, category, " +
                       "crop_type, unit_type, price_per_unit, stock_quantity, reorder_level, " +
                       "expiry_date, manufacturer, description, status) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, product.getSupplierId());
            pstmt.setString(2, product.getProductName());
            pstmt.setString(3, product.getProductType());
            pstmt.setString(4, product.getCategory());
            pstmt.setString(5, product.getCropType());
            pstmt.setString(6, product.getUnitType());
            pstmt.setDouble(7, product.getPricePerUnit());
            pstmt.setInt(8, product.getStockQuantity());
            pstmt.setInt(9, product.getReorderLevel());
            pstmt.setDate(10, product.getExpiryDate());
            pstmt.setString(11, product.getManufacturer());
            pstmt.setString(12, product.getDescription());
            pstmt.setString(13, product.getStatus());
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // READ
    public Product getProductById(int productId) throws SQLException {
        String query = "SELECT p.*, s.company_name as supplier_name " +
                       "FROM products p " +
                       "JOIN fertilizer_suppliers s ON p.supplier_id = s.supplier_id " +
                       "WHERE p.product_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, productId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractProductFromResultSet(rs);
            }
        }
        return null;
    }
    
    // READ ALL
    public List<Product> getAllProducts() throws SQLException {
        List<Product> products = new ArrayList<>();
        String query = "SELECT p.*, s.company_name as supplier_name " +
                       "FROM products p " +
                       "JOIN fertilizer_suppliers s ON p.supplier_id = s.supplier_id " +
                       "ORDER BY p.product_id DESC";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                products.add(extractProductFromResultSet(rs));
            }
        }
        return products;
    }
    
    // READ AVAILABLE
    public List<Product> getAvailableProducts() throws SQLException {
        List<Product> products = new ArrayList<>();
        String query = "SELECT p.*, s.company_name as supplier_name " +
                       "FROM products p " +
                       "JOIN fertilizer_suppliers s ON p.supplier_id = s.supplier_id " +
                       "WHERE p.status = 'AVAILABLE' AND p.stock_quantity > 0 " +
                       "ORDER BY p.product_name";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                products.add(extractProductFromResultSet(rs));
            }
        }
        return products;
    }
    
    // UPDATE
    public boolean updateProduct(Product product) throws SQLException {
        String query = "UPDATE products SET supplier_id=?, product_name=?, product_type=?, " +
                       "category=?, crop_type=?, unit_type=?, price_per_unit=?, stock_quantity=?, " +
                       "reorder_level=?, expiry_date=?, manufacturer=?, description=?, status=? " +
                       "WHERE product_id=?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, product.getSupplierId());
            pstmt.setString(2, product.getProductName());
            pstmt.setString(3, product.getProductType());
            pstmt.setString(4, product.getCategory());
            pstmt.setString(5, product.getCropType());
            pstmt.setString(6, product.getUnitType());
            pstmt.setDouble(7, product.getPricePerUnit());
            pstmt.setInt(8, product.getStockQuantity());
            pstmt.setInt(9, product.getReorderLevel());
            pstmt.setDate(10, product.getExpiryDate());
            pstmt.setString(11, product.getManufacturer());
            pstmt.setString(12, product.getDescription());
            pstmt.setString(13, product.getStatus());
            pstmt.setInt(14, product.getProductId());
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // UPDATE STOCK
    public boolean reduceStock(int productId, int quantity) throws SQLException {
        String query = "UPDATE products SET stock_quantity = stock_quantity - ? " +
                       "WHERE product_id = ? AND stock_quantity >= ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, quantity);
            pstmt.setInt(2, productId);
            pstmt.setInt(3, quantity);
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // DELETE
    public boolean deleteProduct(int productId) throws SQLException {
        String query = "DELETE FROM products WHERE product_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, productId);
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // SEARCH
    public List<Product> searchProducts(String searchTerm) throws SQLException {
        List<Product> products = new ArrayList<>();
        String query = "SELECT p.*, s.company_name as supplier_name " +
                       "FROM products p " +
                       "JOIN fertilizer_suppliers s ON p.supplier_id = s.supplier_id " +
                       "WHERE p.product_name LIKE ? OR p.product_type LIKE ? OR " +
                       "p.category LIKE ? OR p.crop_type LIKE ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            String searchPattern = "%" + searchTerm + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            pstmt.setString(3, searchPattern);
            pstmt.setString(4, searchPattern);
            
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                products.add(extractProductFromResultSet(rs));
            }
        }
        return products;
    }
    
    // Helper method
    private Product extractProductFromResultSet(ResultSet rs) throws SQLException {
        Product product = new Product();
        product.setProductId(rs.getInt("product_id"));
        product.setSupplierId(rs.getInt("supplier_id"));
        product.setProductName(rs.getString("product_name"));
        product.setProductType(rs.getString("product_type"));
        product.setCategory(rs.getString("category"));
        product.setCropType(rs.getString("crop_type"));
        product.setUnitType(rs.getString("unit_type"));
        product.setPricePerUnit(rs.getDouble("price_per_unit"));
        product.setStockQuantity(rs.getInt("stock_quantity"));
        product.setReorderLevel(rs.getInt("reorder_level"));
        product.setExpiryDate(rs.getDate("expiry_date"));
        product.setManufacturer(rs.getString("manufacturer"));
        product.setDescription(rs.getString("description"));
        product.setStatus(rs.getString("status"));
        product.setCreatedAt(rs.getTimestamp("created_at"));
        product.setSupplierName(rs.getString("supplier_name"));
        return product;
    }
}