package com.fertilizersystem.dao;

import com.fertilizersystem.model.FertilizerSupplier;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FertilizerSupplierDAO {
    
    private Connection connection;
    
    public FertilizerSupplierDAO() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }
    
    // CREATE
    public boolean addSupplier(FertilizerSupplier supplier) throws SQLException {
        String query = "INSERT INTO fertilizer_suppliers (company_name, contact_person, email, phone, " +
                       "address, city, country, business_type, license_number, rating) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, supplier.getCompanyName());
            pstmt.setString(2, supplier.getContactPerson());
            pstmt.setString(3, supplier.getEmail());
            pstmt.setString(4, supplier.getPhone());
            pstmt.setString(5, supplier.getAddress());
            pstmt.setString(6, supplier.getCity());
            pstmt.setString(7, supplier.getCountry());
            pstmt.setString(8, supplier.getBusinessType());
            pstmt.setString(9, supplier.getLicenseNumber());
            pstmt.setDouble(10, supplier.getRating());
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // READ
    public FertilizerSupplier getSupplierById(int supplierId) throws SQLException {
        String query = "SELECT * FROM fertilizer_suppliers WHERE supplier_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, supplierId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractSupplierFromResultSet(rs);
            }
        }
        return null;
    }
    
    // READ ALL
    public List<FertilizerSupplier> getAllSuppliers() throws SQLException {
        List<FertilizerSupplier> suppliers = new ArrayList<>();
        String query = "SELECT * FROM fertilizer_suppliers ORDER BY supplier_id DESC";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                suppliers.add(extractSupplierFromResultSet(rs));
            }
        }
        return suppliers;
    }
    
    // UPDATE
    public boolean updateSupplier(FertilizerSupplier supplier) throws SQLException {
        String query = "UPDATE fertilizer_suppliers SET company_name=?, contact_person=?, email=?, " +
                       "phone=?, address=?, city=?, country=?, business_type=?, license_number=?, rating=? " +
                       "WHERE supplier_id=?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, supplier.getCompanyName());
            pstmt.setString(2, supplier.getContactPerson());
            pstmt.setString(3, supplier.getEmail());
            pstmt.setString(4, supplier.getPhone());
            pstmt.setString(5, supplier.getAddress());
            pstmt.setString(6, supplier.getCity());
            pstmt.setString(7, supplier.getCountry());
            pstmt.setString(8, supplier.getBusinessType());
            pstmt.setString(9, supplier.getLicenseNumber());
            pstmt.setDouble(10, supplier.getRating());
            pstmt.setInt(11, supplier.getSupplierId());
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // DELETE
    public boolean deleteSupplier(int supplierId) throws SQLException {
        String query = "DELETE FROM fertilizer_suppliers WHERE supplier_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, supplierId);
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // SEARCH
    public List<FertilizerSupplier> searchSuppliers(String searchTerm) throws SQLException {
        List<FertilizerSupplier> suppliers = new ArrayList<>();
        String query = "SELECT * FROM fertilizer_suppliers WHERE company_name LIKE ? OR " +
                       "contact_person LIKE ? OR city LIKE ? OR business_type LIKE ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            String searchPattern = "%" + searchTerm + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            pstmt.setString(3, searchPattern);
            pstmt.setString(4, searchPattern);
            
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                suppliers.add(extractSupplierFromResultSet(rs));
            }
        }
        return suppliers;
    }
    
    // Helper method
    private FertilizerSupplier extractSupplierFromResultSet(ResultSet rs) throws SQLException {
        FertilizerSupplier supplier = new FertilizerSupplier();
        supplier.setSupplierId(rs.getInt("supplier_id"));
        supplier.setCompanyName(rs.getString("company_name"));
        supplier.setContactPerson(rs.getString("contact_person"));
        supplier.setEmail(rs.getString("email"));
        supplier.setPhone(rs.getString("phone"));
        supplier.setAddress(rs.getString("address"));
        supplier.setCity(rs.getString("city"));
        supplier.setCountry(rs.getString("country"));
        supplier.setBusinessType(rs.getString("business_type"));
        supplier.setLicenseNumber(rs.getString("license_number"));
        supplier.setRating(rs.getDouble("rating"));
        supplier.setCreatedAt(rs.getTimestamp("created_at"));
        return supplier;
    }
}