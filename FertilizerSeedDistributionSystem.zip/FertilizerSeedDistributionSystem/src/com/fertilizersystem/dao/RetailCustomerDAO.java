package com.fertilizersystem.dao;

import com.fertilizersystem.model.RetailCustomer;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RetailCustomerDAO {
    
    private Connection connection;
    
    public RetailCustomerDAO() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }
    
    // CREATE
    public boolean addCustomer(RetailCustomer customer) throws SQLException {
        String query = "INSERT INTO retail_customers (first_name, last_name, email, phone, nic, " +
                       "address, city, customer_type, farm_size, business_name) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, customer.getFirstName());
            pstmt.setString(2, customer.getLastName());
            pstmt.setString(3, customer.getEmail());
            pstmt.setString(4, customer.getPhone());
            pstmt.setString(5, customer.getNic());
            pstmt.setString(6, customer.getAddress());
            pstmt.setString(7, customer.getCity());
            pstmt.setString(8, customer.getCustomerType());
            pstmt.setDouble(9, customer.getFarmSize());
            pstmt.setString(10, customer.getBusinessName());
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // READ
    public RetailCustomer getCustomerById(int customerId) throws SQLException {
        String query = "SELECT * FROM retail_customers WHERE customer_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, customerId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractCustomerFromResultSet(rs);
            }
        }
        return null;
    }
    
    // READ ALL
    public List<RetailCustomer> getAllCustomers() throws SQLException {
        List<RetailCustomer> customers = new ArrayList<>();
        String query = "SELECT * FROM retail_customers ORDER BY customer_id DESC";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                customers.add(extractCustomerFromResultSet(rs));
            }
        }
        return customers;
    }
    
    // UPDATE
    public boolean updateCustomer(RetailCustomer customer) throws SQLException {
        String query = "UPDATE retail_customers SET first_name=?, last_name=?, email=?, phone=?, " +
                       "nic=?, address=?, city=?, customer_type=?, farm_size=?, business_name=? " +
                       "WHERE customer_id=?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, customer.getFirstName());
            pstmt.setString(2, customer.getLastName());
            pstmt.setString(3, customer.getEmail());
            pstmt.setString(4, customer.getPhone());
            pstmt.setString(5, customer.getNic());
            pstmt.setString(6, customer.getAddress());
            pstmt.setString(7, customer.getCity());
            pstmt.setString(8, customer.getCustomerType());
            pstmt.setDouble(9, customer.getFarmSize());
            pstmt.setString(10, customer.getBusinessName());
            pstmt.setInt(11, customer.getCustomerId());
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // DELETE
    public boolean deleteCustomer(int customerId) throws SQLException {
        String query = "DELETE FROM retail_customers WHERE customer_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, customerId);
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // SEARCH
    public List<RetailCustomer> searchCustomers(String searchTerm) throws SQLException {
        List<RetailCustomer> customers = new ArrayList<>();
        String query = "SELECT * FROM retail_customers WHERE first_name LIKE ? OR " +
                       "last_name LIKE ? OR email LIKE ? OR phone LIKE ? OR " +
                       "customer_type LIKE ? OR city LIKE ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            String searchPattern = "%" + searchTerm + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            pstmt.setString(3, searchPattern);
            pstmt.setString(4, searchPattern);
            pstmt.setString(5, searchPattern);
            pstmt.setString(6, searchPattern);
            
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                customers.add(extractCustomerFromResultSet(rs));
            }
        }
        return customers;
    }
    
    // UPDATE LOYALTY POINTS
    public boolean updateLoyaltyPoints(int customerId, int points) throws SQLException {
        String query = "UPDATE retail_customers SET loyalty_points = loyalty_points + ? " +
                       "WHERE customer_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, points);
            pstmt.setInt(2, customerId);
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // UPDATE TOTAL PURCHASES
    public boolean updateTotalPurchases(int customerId, double amount) throws SQLException {
        String query = "UPDATE retail_customers SET total_purchases = total_purchases + ? " +
                       "WHERE customer_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setDouble(1, amount);
            pstmt.setInt(2, customerId);
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // Helper method
    private RetailCustomer extractCustomerFromResultSet(ResultSet rs) throws SQLException {
        RetailCustomer customer = new RetailCustomer();
        customer.setCustomerId(rs.getInt("customer_id"));
        customer.setFirstName(rs.getString("first_name"));
        customer.setLastName(rs.getString("last_name"));
        customer.setEmail(rs.getString("email"));
        customer.setPhone(rs.getString("phone"));
        customer.setNic(rs.getString("nic"));
        customer.setAddress(rs.getString("address"));
        customer.setCity(rs.getString("city"));
        customer.setCustomerType(rs.getString("customer_type"));
        customer.setFarmSize(rs.getDouble("farm_size"));
        customer.setBusinessName(rs.getString("business_name"));
        customer.setLoyaltyPoints(rs.getInt("loyalty_points"));
        customer.setTotalPurchases(rs.getDouble("total_purchases"));
        customer.setCreatedAt(rs.getTimestamp("created_at"));
        return customer;
    }
}