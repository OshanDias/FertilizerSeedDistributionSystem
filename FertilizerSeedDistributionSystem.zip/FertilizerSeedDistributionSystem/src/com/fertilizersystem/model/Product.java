package com.fertilizersystem.model;

import java.sql.Date;
import java.sql.Timestamp;

public class Product {
    
    private int productId;
    private int supplierId;
    private String productName;
    private String productType;
    private String category;
    private String cropType;
    private String unitType;
    private double pricePerUnit;
    private int stockQuantity;
    private int reorderLevel;
    private Date expiryDate;
    private String manufacturer;
    private String description;
    private String status;
    private Timestamp createdAt;
    
    // From JOIN
    private String supplierName;
    
    public Product() {
    }
    
    public Product(int supplierId, String productName, String productType, String category,
                  String cropType, String unitType, double pricePerUnit, int stockQuantity,
                  int reorderLevel, Date expiryDate, String manufacturer, String description, String status) {
        this.supplierId = supplierId;
        this.productName = productName;
        this.productType = productType;
        this.category = category;
        this.cropType = cropType;
        this.unitType = unitType;
        this.pricePerUnit = pricePerUnit;
        this.stockQuantity = stockQuantity;
        this.reorderLevel = reorderLevel;
        this.expiryDate = expiryDate;
        this.manufacturer = manufacturer;
        this.description = description;
        this.status = status;
    }
    
    // Getters and Setters
    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }
    
    public int getSupplierId() { return supplierId; }
    public void setSupplierId(int supplierId) { this.supplierId = supplierId; }
    
    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }
    
    public String getProductType() { return productType; }
    public void setProductType(String productType) { this.productType = productType; }
    
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    
    public String getCropType() { return cropType; }
    public void setCropType(String cropType) { this.cropType = cropType; }
    
    public String getUnitType() { return unitType; }
    public void setUnitType(String unitType) { this.unitType = unitType; }
    
    public double getPricePerUnit() { return pricePerUnit; }
    public void setPricePerUnit(double pricePerUnit) { this.pricePerUnit = pricePerUnit; }
    
    public int getStockQuantity() { return stockQuantity; }
    public void setStockQuantity(int stockQuantity) { this.stockQuantity = stockQuantity; }
    
    public int getReorderLevel() { return reorderLevel; }
    public void setReorderLevel(int reorderLevel) { this.reorderLevel = reorderLevel; }
    
    public Date getExpiryDate() { return expiryDate; }
    public void setExpiryDate(Date expiryDate) { this.expiryDate = expiryDate; }
    
    public String getManufacturer() { return manufacturer; }
    public void setManufacturer(String manufacturer) { this.manufacturer = manufacturer; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
    
    public String getSupplierName() { return supplierName; }
    public void setSupplierName(String supplierName) { this.supplierName = supplierName; }
    
    @Override
    public String toString() {
        return "Product{" +
                "productId=" + productId +
                ", productName='" + productName + '\'' +
                ", productType='" + productType + '\'' +
                ", pricePerUnit=" + pricePerUnit +
                ", stockQuantity=" + stockQuantity +
                '}';
    }
}