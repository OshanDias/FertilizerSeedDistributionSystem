package com.fertilizersystem.model;

import java.sql.Timestamp;

public class FertilizerSupplier {
    
    private int supplierId;
    private String companyName;
    private String contactPerson;
    private String email;
    private String phone;
    private String address;
    private String city;
    private String country;
    private String businessType;
    private String licenseNumber;
    private double rating;
    private Timestamp createdAt;
    
    public FertilizerSupplier() {
    }
    
    public FertilizerSupplier(String companyName, String contactPerson, String email, String phone,
                             String address, String city, String country, String businessType, 
                             String licenseNumber, double rating) {
        this.companyName = companyName;
        this.contactPerson = contactPerson;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.city = city;
        this.country = country;
        this.businessType = businessType;
        this.licenseNumber = licenseNumber;
        this.rating = rating;
    }
    
    public FertilizerSupplier(int supplierId, String companyName, String contactPerson, String email,
                             String phone, String address, String city, String country, 
                             String businessType, String licenseNumber, double rating) {
        this.supplierId = supplierId;
        this.companyName = companyName;
        this.contactPerson = contactPerson;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.city = city;
        this.country = country;
        this.businessType = businessType;
        this.licenseNumber = licenseNumber;
        this.rating = rating;
    }
    
    // Getters and Setters
    public int getSupplierId() { return supplierId; }
    public void setSupplierId(int supplierId) { this.supplierId = supplierId; }
    
    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }
    
    public String getContactPerson() { return contactPerson; }
    public void setContactPerson(String contactPerson) { this.contactPerson = contactPerson; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    
    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }
    
    public String getBusinessType() { return businessType; }
    public void setBusinessType(String businessType) { this.businessType = businessType; }
    
    public String getLicenseNumber() { return licenseNumber; }
    public void setLicenseNumber(String licenseNumber) { this.licenseNumber = licenseNumber; }
    
    public double getRating() { return rating; }
    public void setRating(double rating) { this.rating = rating; }
    
    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
    
    @Override
    public String toString() {
        return "FertilizerSupplier{" +
                "supplierId=" + supplierId +
                ", companyName='" + companyName + '\'' +
                ", businessType='" + businessType + '\'' +
                ", rating=" + rating +
                '}';
    }
}