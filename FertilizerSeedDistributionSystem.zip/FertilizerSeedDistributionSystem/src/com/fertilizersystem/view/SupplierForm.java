package com.fertilizersystem.view;

import com.fertilizersystem.dao.FertilizerSupplierDAO;
import com.fertilizersystem.model.FertilizerSupplier;
import com.fertilizersystem.util.Validator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/**
 * Supplier Management Form - 3-COLUMN HORIZONTAL LAYOUT (Ocean Blue)
 */
public class SupplierForm extends JFrame {
    
    private FertilizerSupplierDAO supplierDAO;
    private DefaultTableModel tableModel;
    
    private JTable tblSuppliers;
    private JTextField txtCompanyName, txtContactPerson, txtEmail, txtPhone;
    private JTextField txtAddress, txtCity, txtCountry, txtLicenseNumber, txtRating;
    private JComboBox<String> cmbBusinessType;
    private JTextField txtSearch;
    
    private JButton btnAdd, btnUpdate, btnDelete, btnClear, btnSearch, btnRefresh, btnBack;
    
    private int selectedSupplierId = -1;
    
    public SupplierForm() {
        supplierDAO = new FertilizerSupplierDAO();
        initComponents();
        loadSuppliers();
        setLocationRelativeTo(null);
    }
    
    private void initComponents() {
        setTitle("Supplier Management ");
        setSize(1500, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        setLayout(null);
        getContentPane().setBackground(new Color(236, 240, 241));
        
        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(null);
        headerPanel.setBackground(new Color(41, 128, 185));
        headerPanel.setBounds(0, 0, 1500, 60);
        add(headerPanel);
        
        JLabel lblTitle = new JLabel(" SUPPLIER MANAGEMENT");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(30, 15, 400, 30);
        headerPanel.add(lblTitle);
        
        btnBack = new JButton("← BACK");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnBack.setBounds(1350, 15, 120, 32);
        btnBack.setBackground(new Color(231, 76, 60));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setBorderPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.addActionListener(e -> dispose());
        headerPanel.add(btnBack);
        
        // LEFT COLUMN - Input Fields (30%)
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(null);
        leftPanel.setBackground(Color.WHITE);
        leftPanel.setBounds(20, 80, 420, 700);
        leftPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(41, 128, 185), 2),
            "Supplier Details",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(44, 62, 80)
        ));
        add(leftPanel);
        
        int yPos = 35;
        int gap = 65;
        
        addLabel(leftPanel, "Company Name:", 15, yPos);
        txtCompanyName = addTextField(leftPanel, 15, yPos + 22, 390);
        
        yPos += gap;
        addLabel(leftPanel, "Contact Person:", 15, yPos);
        txtContactPerson = addTextField(leftPanel, 15, yPos + 22, 390);
        
        yPos += gap;
        addLabel(leftPanel, "Email:", 15, yPos);
        txtEmail = addTextField(leftPanel, 15, yPos + 22, 390);
        
        yPos += gap;
        addLabel(leftPanel, "Phone:", 15, yPos);
        txtPhone = addTextField(leftPanel, 15, yPos + 22, 390);
        
        yPos += gap;
        addLabel(leftPanel, "City:", 15, yPos);
        txtCity = addTextField(leftPanel, 15, yPos + 22, 390);
        
        yPos += gap;
        addLabel(leftPanel, "Country:", 15, yPos);
        txtCountry = addTextField(leftPanel, 15, yPos + 22, 390);
        txtCountry.setText("Sri Lanka");
        
        yPos += gap;
        addLabel(leftPanel, "Business Type:", 15, yPos);
        String[] types = {"Manufacturer", "Distributor", "Importer", "Local Producer"};
        cmbBusinessType = new JComboBox<>(types);
        cmbBusinessType.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cmbBusinessType.setBounds(15, yPos + 22, 390, 32);
        leftPanel.add(cmbBusinessType);
        
        yPos += gap;
        addLabel(leftPanel, "License Number:", 15, yPos);
        txtLicenseNumber = addTextField(leftPanel, 15, yPos + 22, 390);
        
        yPos += gap;
        addLabel(leftPanel, "Rating (0.0 - 5.0):", 15, yPos);
        txtRating = addTextField(leftPanel, 15, yPos + 22, 390);
        txtRating.setText("0.0");
        
        yPos += gap;
        addLabel(leftPanel, "Address:", 15, yPos);
        txtAddress = addTextField(leftPanel, 15, yPos + 22, 390);
        
        // MIDDLE COLUMN - Action Buttons (20%)
        JPanel middlePanel = new JPanel();
        middlePanel.setLayout(null);
        middlePanel.setBackground(Color.WHITE);
        middlePanel.setBounds(460, 80, 280, 700);
        middlePanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(41, 128, 185), 2),
            "Actions",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(44, 62, 80)
        ));
        add(middlePanel);
        
        int btnY = 40;
        int btnGap = 60;
        
        btnAdd = createButton(" ADD", 25, btnY, new Color(22, 160, 133), 230);
        btnAdd.addActionListener(e -> addSupplier());
        middlePanel.add(btnAdd);
        
        btnY += btnGap;
        btnUpdate = createButton(" UPDATE", 25, btnY, new Color(41, 128, 185), 230);
        btnUpdate.addActionListener(e -> updateSupplier());
        middlePanel.add(btnUpdate);
        
        btnY += btnGap;
        btnDelete = createButton("🗑️ DELETE", 25, btnY, new Color(231, 76, 60), 230);
        btnDelete.addActionListener(e -> deleteSupplier());
        middlePanel.add(btnDelete);
        
        btnY += btnGap;
        btnClear = createButton(" CLEAR", 25, btnY, new Color(149, 165, 166), 230);
        btnClear.addActionListener(e -> clearFields());
        middlePanel.add(btnClear);
        
        // Info Panel
        JTextArea txtInfo = new JTextArea();
        txtInfo.setEditable(false);
        txtInfo.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        txtInfo.setLineWrap(true);
        txtInfo.setWrapStyleWord(true);
        txtInfo.setBackground(new Color(236, 240, 241));
        txtInfo.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        txtInfo.setText(" INSTRUCTIONS:\n\n" +
                       "• Fill all required fields\n" +
                       "• Select row to UPDATE/DELETE\n" +
                       "• License must be unique\n" +
                       "• Rating: 0.0 to 5.0\n" +
                       "• Phone: 0xxxxxxxxx format");
        
        JScrollPane scrollInfo = new JScrollPane(txtInfo);
        scrollInfo.setBounds(25, 280, 230, 400);
        scrollInfo.setBorder(BorderFactory.createLineBorder(new Color(26, 188, 156), 1));
        middlePanel.add(scrollInfo);
        
        // RIGHT COLUMN - Table (50%)
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(null);
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setBounds(760, 80, 720, 700);
        rightPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(41, 128, 185), 2),
            "Supplier Records",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(44, 62, 80)
        ));
        add(rightPanel);
        
        // Search
        JLabel lblSearch = new JLabel(" Search:");
        lblSearch.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblSearch.setBounds(15, 35, 80, 30);
        rightPanel.add(lblSearch);
        
        txtSearch = new JTextField();
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtSearch.setBounds(95, 35, 390, 30);
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(26, 188, 156), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        rightPanel.add(txtSearch);
        
        btnSearch = createButton("SEARCH", 500, 35, new Color(41, 128, 185), 100);
        btnSearch.addActionListener(e -> searchSuppliers());
        rightPanel.add(btnSearch);
        
        btnRefresh = createButton("REFRESH", 610, 35, new Color(26, 188, 156), 95);
        btnRefresh.addActionListener(e -> loadSuppliers());
        rightPanel.add(btnRefresh);
        
        // Table
        String[] columns = {"ID", "Company", "Contact", "Email", "Phone", "City", "Type", "Rating"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tblSuppliers = new JTable(tableModel);
        tblSuppliers.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tblSuppliers.setRowHeight(26);
        tblSuppliers.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 11));
        tblSuppliers.getTableHeader().setBackground(new Color(41, 128, 185));
        tblSuppliers.getTableHeader().setForeground(Color.WHITE);
        tblSuppliers.setSelectionBackground(new Color(52, 152, 219));
        tblSuppliers.setSelectionForeground(Color.WHITE);
        tblSuppliers.setGridColor(new Color(200, 200, 200));
        
        tblSuppliers.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedSupplier();
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(tblSuppliers);
        scrollPane.setBounds(15, 80, 690, 605);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(41, 128, 185), 1));
        rightPanel.add(scrollPane);
    }
    
    private void addLabel(JPanel panel, String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(new Color(44, 62, 80));
        label.setBounds(x, y, 300, 18);
        panel.add(label);
    }
    
    private JTextField addTextField(JPanel panel, int x, int y, int width) {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setBounds(x, y, width, 32);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(26, 188, 156), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panel.add(field);
        return field;
    }
    
    private JButton createButton(String text, int x, int y, Color color, int width) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBounds(x, y, width, 40);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(color);
            }
        });
        
        return btn;
    }
    
    private void loadSuppliers() {
        try {
            tableModel.setRowCount(0);
            List<FertilizerSupplier> suppliers = supplierDAO.getAllSuppliers();
            
            for (FertilizerSupplier supplier : suppliers) {
                Object[] row = {
                    supplier.getSupplierId(),
                    supplier.getCompanyName(),
                    supplier.getContactPerson(),
                    supplier.getEmail(),
                    supplier.getPhone(),
                    supplier.getCity(),
                    supplier.getBusinessType(),
                    String.format("⭐ %.1f", supplier.getRating())
                };
                tableModel.addRow(row);
            }
            
        } catch (SQLException e) {
            showError("Error loading suppliers: " + e.getMessage());
        }
    }
    
    private void loadSelectedSupplier() {
        int selectedRow = tblSuppliers.getSelectedRow();
        if (selectedRow >= 0) {
            selectedSupplierId = (int) tableModel.getValueAt(selectedRow, 0);
            
            try {
                FertilizerSupplier supplier = supplierDAO.getSupplierById(selectedSupplierId);
                if (supplier != null) {
                    txtCompanyName.setText(supplier.getCompanyName());
                    txtContactPerson.setText(supplier.getContactPerson());
                    txtEmail.setText(supplier.getEmail());
                    txtPhone.setText(supplier.getPhone());
                    txtCity.setText(supplier.getCity());
                    txtCountry.setText(supplier.getCountry());
                    cmbBusinessType.setSelectedItem(supplier.getBusinessType());
                    txtLicenseNumber.setText(supplier.getLicenseNumber());
                    txtRating.setText(String.format("%.1f", supplier.getRating()));
                    txtAddress.setText(supplier.getAddress());
                }
            } catch (SQLException e) {
                showError("Error loading supplier: " + e.getMessage());
            }
        }
    }
    
    private void addSupplier() {
        if (!validateInputs()) return;
        
        try {
            FertilizerSupplier supplier = new FertilizerSupplier();
            supplier.setCompanyName(txtCompanyName.getText().trim());
            supplier.setContactPerson(txtContactPerson.getText().trim());
            supplier.setEmail(txtEmail.getText().trim());
            supplier.setPhone(txtPhone.getText().trim());
            supplier.setCity(txtCity.getText().trim());
            supplier.setCountry(txtCountry.getText().trim());
            supplier.setBusinessType((String) cmbBusinessType.getSelectedItem());
            supplier.setLicenseNumber(txtLicenseNumber.getText().trim().toUpperCase());
            supplier.setRating(Double.parseDouble(txtRating.getText().trim()));
            supplier.setAddress(txtAddress.getText().trim());
            
            boolean success = supplierDAO.addSupplier(supplier);
            
            if (success) {
                showSuccess("✅ Supplier added successfully!");
                loadSuppliers();
                clearFields();
            }
            
        } catch (SQLException e) {
            showError("Error: " + e.getMessage());
        }
    }
    
    private void updateSupplier() {
        if (selectedSupplierId == -1) {
            showWarning("Please select a supplier to update!");
            return;
        }
        
        if (!validateInputs()) return;
        
        try {
            FertilizerSupplier supplier = new FertilizerSupplier();
            supplier.setSupplierId(selectedSupplierId);
            supplier.setCompanyName(txtCompanyName.getText().trim());
            supplier.setContactPerson(txtContactPerson.getText().trim());
            supplier.setEmail(txtEmail.getText().trim());
            supplier.setPhone(txtPhone.getText().trim());
            supplier.setCity(txtCity.getText().trim());
            supplier.setCountry(txtCountry.getText().trim());
            supplier.setBusinessType((String) cmbBusinessType.getSelectedItem());
            supplier.setLicenseNumber(txtLicenseNumber.getText().trim().toUpperCase());
            supplier.setRating(Double.parseDouble(txtRating.getText().trim()));
            supplier.setAddress(txtAddress.getText().trim());
            
            boolean success = supplierDAO.updateSupplier(supplier);
            
            if (success) {
                showSuccess("✅ Supplier updated successfully!");
                loadSuppliers();
                clearFields();
            }
            
        } catch (SQLException e) {
            showError("Error: " + e.getMessage());
        }
    }
    
    private void deleteSupplier() {
        if (selectedSupplierId == -1) {
            showWarning("Please select a supplier to delete!");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Delete this supplier?",
            "Confirm",
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                boolean success = supplierDAO.deleteSupplier(selectedSupplierId);
                if (success) {
                    showSuccess("✅ Supplier deleted!");
                    loadSuppliers();
                    clearFields();
                }
            } catch (SQLException e) {
                showError("Error: " + e.getMessage());
            }
        }
    }
    
    private void searchSuppliers() {
        String searchTerm = txtSearch.getText().trim();
        if (searchTerm.isEmpty()) {
            loadSuppliers();
            return;
        }
        
        try {
            tableModel.setRowCount(0);
            List<FertilizerSupplier> suppliers = supplierDAO.searchSuppliers(searchTerm);
            
            for (FertilizerSupplier supplier : suppliers) {
                Object[] row = {
                    supplier.getSupplierId(),
                    supplier.getCompanyName(),
                    supplier.getContactPerson(),
                    supplier.getEmail(),
                    supplier.getPhone(),
                    supplier.getCity(),
                    supplier.getBusinessType(),
                    String.format("⭐ %.1f", supplier.getRating())
                };
                tableModel.addRow(row);
            }
            
            showInfo("Found " + suppliers.size() + " supplier(s)");
            
        } catch (SQLException e) {
            showError("Error: " + e.getMessage());
        }
    }
    
    private void clearFields() {
        txtCompanyName.setText("");
        txtContactPerson.setText("");
        txtEmail.setText("");
        txtPhone.setText("");
        txtCity.setText("");
        txtCountry.setText("Sri Lanka");
        cmbBusinessType.setSelectedIndex(0);
        txtLicenseNumber.setText("");
        txtRating.setText("0.0");
        txtAddress.setText("");
        txtSearch.setText("");
        selectedSupplierId = -1;
        tblSuppliers.clearSelection();
    }
    
    private boolean validateInputs() {
        if (Validator.isEmpty(txtCompanyName.getText())) {
            showWarning("Company name required!");
            return false;
        }
        
        if (!Validator.isValidEmail(txtEmail.getText().trim())) {
            showWarning("Invalid email!");
            return false;
        }
        
        if (!Validator.isValidPhone(txtPhone.getText().trim())) {
            showWarning("Invalid phone!");
            return false;
        }
        
        try {
            double rating = Double.parseDouble(txtRating.getText().trim());
            if (!Validator.isValidRating(rating)) {
                showWarning("Rating must be 0.0-5.0!");
                return false;
            }
        } catch (NumberFormatException e) {
            showWarning("Invalid rating!");
            return false;
        }
        
        return true;
    }
    
    private void showSuccess(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Success", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void showWarning(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Warning", JOptionPane.WARNING_MESSAGE);
    }
    
    private void showInfo(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Info", JOptionPane.INFORMATION_MESSAGE);
    }
}