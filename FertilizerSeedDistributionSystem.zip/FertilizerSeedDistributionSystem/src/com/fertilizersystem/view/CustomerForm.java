package com.fertilizersystem.view;

import com.fertilizersystem.dao.RetailCustomerDAO;
import com.fertilizersystem.model.RetailCustomer;
import com.fertilizersystem.util.Validator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/**
 * Customer Management Form - 3-COLUMN HORIZONTAL LAYOUT
 */
public class CustomerForm extends JFrame {
    
    private RetailCustomerDAO customerDAO;
    private DefaultTableModel tableModel;
    
    private JTable tblCustomers;
    private JTextField txtFirstName, txtLastName, txtEmail, txtPhone, txtNic;
    private JTextField txtAddress, txtCity, txtFarmSize, txtBusinessName;
    private JComboBox<String> cmbCustomerType;
    private JTextField txtSearch;
    
    private JButton btnAdd, btnUpdate, btnDelete, btnClear, btnSearch, btnRefresh, btnBack;
    
    private int selectedCustomerId = -1;
    
    public CustomerForm() {
        customerDAO = new RetailCustomerDAO();
        initComponents();
        loadCustomers();
        setLocationRelativeTo(null);
    }
    
    private void initComponents() {
        setTitle("Customer Management ");
        setSize(1500, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        setLayout(null);
        getContentPane().setBackground(new Color(236, 240, 241));
        
        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(null);
        headerPanel.setBackground(new Color(41, 128, 185));
        headerPanel.setBounds(0, 0, 1500, 60);
        add(headerPanel);
        
        JLabel lblTitle = new JLabel(" CUSTOMER MANAGEMENT");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(30, 15, 400, 30);
        headerPanel.add(lblTitle);
        
        btnBack = new JButton("← BACK");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnBack.setBounds(1350, 15, 120, 32);
        btnBack.setBackground(new Color(231, 76, 60));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setBorderPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.addActionListener(e -> dispose());
        headerPanel.add(btnBack);
        
        // LEFT COLUMN - Input Fields
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(null);
        leftPanel.setBackground(Color.WHITE);
        leftPanel.setBounds(20, 80, 420, 700);
        leftPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(41, 128, 185), 2),
            "Customer Details",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(44, 62, 80)
        ));
        add(leftPanel);
        
        int yPos = 35;
        int gap = 65;
        
        addLabel(leftPanel, "First Name:", 15, yPos);
        txtFirstName = addTextField(leftPanel, 15, yPos + 22, 390);
        
        yPos += gap;
        addLabel(leftPanel, "Last Name:", 15, yPos);
        txtLastName = addTextField(leftPanel, 15, yPos + 22, 390);
        
        yPos += gap;
        addLabel(leftPanel, "Email:", 15, yPos);
        txtEmail = addTextField(leftPanel, 15, yPos + 22, 390);
        
        yPos += gap;
        addLabel(leftPanel, "Phone:", 15, yPos);
        txtPhone = addTextField(leftPanel, 15, yPos + 22, 390);
        
        yPos += gap;
        addLabel(leftPanel, "NIC:", 15, yPos);
        txtNic = addTextField(leftPanel, 15, yPos + 22, 390);
        
        yPos += gap;
        addLabel(leftPanel, "Address:", 15, yPos);
        txtAddress = addTextField(leftPanel, 15, yPos + 22, 390);
        
        yPos += gap;
        addLabel(leftPanel, "City:", 15, yPos);
        txtCity = addTextField(leftPanel, 15, yPos + 22, 390);
        
        yPos += gap;
        addLabel(leftPanel, "Customer Type:", 15, yPos);
        String[] types = {"Farmer", "Retailer", "Wholesaler", "Individual"};
        cmbCustomerType = new JComboBox<>(types);
        cmbCustomerType.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cmbCustomerType.setBounds(15, yPos + 22, 390, 32);
        cmbCustomerType.addActionListener(e -> toggleFields());
        leftPanel.add(cmbCustomerType);
        
        yPos += gap;
        addLabel(leftPanel, "Farm Size (acres):", 15, yPos);
        txtFarmSize = addTextField(leftPanel, 15, yPos + 22, 190);
        
        addLabel(leftPanel, "Business Name:", 210, yPos);
        txtBusinessName = addTextField(leftPanel, 210, yPos + 22, 195);
        
        // MIDDLE COLUMN - Actions
        JPanel middlePanel = new JPanel();
        middlePanel.setLayout(null);
        middlePanel.setBackground(Color.WHITE);
        middlePanel.setBounds(460, 80, 280, 700);
        middlePanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(41, 128, 185), 2),
            "Actions",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(44, 62, 80)
        ));
        add(middlePanel);
        
        int btnY = 40;
        int btnGap = 60;
        
        btnAdd = createButton(" ADD", 25, btnY, new Color(22, 160, 133), 230);
        btnAdd.addActionListener(e -> addCustomer());
        middlePanel.add(btnAdd);
        
        btnY += btnGap;
        btnUpdate = createButton(" UPDATE", 25, btnY, new Color(41, 128, 185), 230);
        btnUpdate.addActionListener(e -> updateCustomer());
        middlePanel.add(btnUpdate);
        
        btnY += btnGap;
        btnDelete = createButton("🗑️ DELETE", 25, btnY, new Color(231, 76, 60), 230);
        btnDelete.addActionListener(e -> deleteCustomer());
        middlePanel.add(btnDelete);
        
        btnY += btnGap;
        btnClear = createButton(" CLEAR", 25, btnY, new Color(149, 165, 166), 230);
        btnClear.addActionListener(e -> clearFields());
        middlePanel.add(btnClear);
        
        // Info Panel
        JTextArea txtInfo = new JTextArea();
        txtInfo.setEditable(false);
        txtInfo.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        txtInfo.setLineWrap(true);
        txtInfo.setWrapStyleWord(true);
        txtInfo.setBackground(new Color(236, 240, 241));
        txtInfo.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        txtInfo.setText(" CUSTOMER INFO:\n\n" +
                       "• Farmer: Enter farm size\n" +
                       "• Retailer/Wholesaler: Enter business name\n" +
                       "• Individual: Both optional\n" +
                       "• NIC: Old (9V) or New (12) format\n" +
                       "• Phone: 0xxxxxxxxx");
        
        JScrollPane scrollInfo = new JScrollPane(txtInfo);
        scrollInfo.setBounds(25, 280, 230, 400);
        scrollInfo.setBorder(BorderFactory.createLineBorder(new Color(26, 188, 156), 1));
        middlePanel.add(scrollInfo);
        
        // RIGHT COLUMN - Table
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(null);
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setBounds(760, 80, 720, 700);
        rightPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(41, 128, 185), 2),
            "Customer Records",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(44, 62, 80)
        ));
        add(rightPanel);
        
        // Search
        JLabel lblSearch = new JLabel(" Search:");
        lblSearch.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblSearch.setBounds(15, 35, 80, 30);
        rightPanel.add(lblSearch);
        
        txtSearch = new JTextField();
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtSearch.setBounds(95, 35, 390, 30);
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(26, 188, 156), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        rightPanel.add(txtSearch);
        
        btnSearch = createButton("SEARCH", 500, 35, new Color(41, 128, 185), 100);
        btnSearch.addActionListener(e -> searchCustomers());
        rightPanel.add(btnSearch);
        
        btnRefresh = createButton("REFRESH", 610, 35, new Color(26, 188, 156), 95);
        btnRefresh.addActionListener(e -> loadCustomers());
        rightPanel.add(btnRefresh);
        
        // Table
        String[] columns = {"ID", "First Name", "Last Name", "Email", "Phone", "NIC", "City", "Type"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tblCustomers = new JTable(tableModel);
        tblCustomers.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        tblCustomers.setRowHeight(26);
        tblCustomers.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 11));
        tblCustomers.getTableHeader().setBackground(new Color(41, 128, 185));
        tblCustomers.getTableHeader().setForeground(Color.WHITE);
        tblCustomers.setSelectionBackground(new Color(52, 152, 219));
        tblCustomers.setSelectionForeground(Color.WHITE);
        
        tblCustomers.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedCustomer();
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(tblCustomers);
        scrollPane.setBounds(15, 80, 690, 605);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(41, 128, 185), 1));
        rightPanel.add(scrollPane);
    }
    
    private void addLabel(JPanel panel, String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(new Color(44, 62, 80));
        label.setBounds(x, y, 300, 18);
        panel.add(label);
    }
    
    private JTextField addTextField(JPanel panel, int x, int y, int width) {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setBounds(x, y, width, 32);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(26, 188, 156), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panel.add(field);
        return field;
    }
    
    private JButton createButton(String text, int x, int y, Color color, int width) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBounds(x, y, width, 40);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(color);
            }
        });
        
        return btn;
    }
    
    private void toggleFields() {
        String type = (String) cmbCustomerType.getSelectedItem();
        
        if ("Farmer".equals(type)) {
            txtFarmSize.setEnabled(true);
            txtBusinessName.setEnabled(false);
            txtBusinessName.setText("");
        } else if ("Retailer".equals(type) || "Wholesaler".equals(type)) {
            txtFarmSize.setEnabled(false);
            txtFarmSize.setText("");
            txtBusinessName.setEnabled(true);
        } else {
            txtFarmSize.setEnabled(true);
            txtBusinessName.setEnabled(true);
        }
    }
    
    private void loadCustomers() {
        try {
            tableModel.setRowCount(0);
            List<RetailCustomer> customers = customerDAO.getAllCustomers();
            
            for (RetailCustomer customer : customers) {
                Object[] row = {
                    customer.getCustomerId(),
                    customer.getFirstName(),
                    customer.getLastName(),
                    customer.getEmail(),
                    customer.getPhone(),
                    customer.getNic(),
                    customer.getCity(),
                    customer.getCustomerType()
                };
                tableModel.addRow(row);
            }
            
        } catch (SQLException e) {
            showError("Error loading customers: " + e.getMessage());
        }
    }
    
    private void loadSelectedCustomer() {
        int selectedRow = tblCustomers.getSelectedRow();
        if (selectedRow >= 0) {
            selectedCustomerId = (int) tableModel.getValueAt(selectedRow, 0);
            
            try {
                RetailCustomer customer = customerDAO.getCustomerById(selectedCustomerId);
                if (customer != null) {
                    txtFirstName.setText(customer.getFirstName());
                    txtLastName.setText(customer.getLastName());
                    txtEmail.setText(customer.getEmail());
                    txtPhone.setText(customer.getPhone());
                    txtNic.setText(customer.getNic());
                    txtAddress.setText(customer.getAddress());
                    txtCity.setText(customer.getCity());
                    cmbCustomerType.setSelectedItem(customer.getCustomerType());
                    txtFarmSize.setText(customer.getFarmSize() > 0 ? String.format("%.2f", customer.getFarmSize()) : "");
                    txtBusinessName.setText(customer.getBusinessName() != null ? customer.getBusinessName() : "");
                    toggleFields();
                }
            } catch (SQLException e) {
                showError("Error loading customer: " + e.getMessage());
            }
        }
    }
    
    private void addCustomer() {
        if (!validateInputs()) return;
        
        try {
            RetailCustomer customer = new RetailCustomer();
            customer.setFirstName(txtFirstName.getText().trim());
            customer.setLastName(txtLastName.getText().trim());
            customer.setEmail(txtEmail.getText().trim());
            customer.setPhone(txtPhone.getText().trim());
            customer.setNic(txtNic.getText().trim());
            customer.setAddress(txtAddress.getText().trim());
            customer.setCity(txtCity.getText().trim());
            customer.setCustomerType((String) cmbCustomerType.getSelectedItem());
            
            String farmSizeStr = txtFarmSize.getText().trim();
            customer.setFarmSize(farmSizeStr.isEmpty() ? 0.0 : Double.parseDouble(farmSizeStr));
            
            customer.setBusinessName(txtBusinessName.getText().trim().isEmpty() ? null : txtBusinessName.getText().trim());
            
            boolean success = customerDAO.addCustomer(customer);
            
            if (success) {
                showSuccess("✅ Customer added successfully!");
                loadCustomers();
                clearFields();
            }
            
        } catch (SQLException e) {
            showError("Error: " + e.getMessage());
        }
    }
    
    private void updateCustomer() {
        if (selectedCustomerId == -1) {
            showWarning("Please select a customer to update!");
            return;
        }
        
        if (!validateInputs()) return;
        
        try {
            RetailCustomer customer = new RetailCustomer();
            customer.setCustomerId(selectedCustomerId);
            customer.setFirstName(txtFirstName.getText().trim());
            customer.setLastName(txtLastName.getText().trim());
            customer.setEmail(txtEmail.getText().trim());
            customer.setPhone(txtPhone.getText().trim());
            customer.setNic(txtNic.getText().trim());
            customer.setAddress(txtAddress.getText().trim());
            customer.setCity(txtCity.getText().trim());
            customer.setCustomerType((String) cmbCustomerType.getSelectedItem());
            
            String farmSizeStr = txtFarmSize.getText().trim();
            customer.setFarmSize(farmSizeStr.isEmpty() ? 0.0 : Double.parseDouble(farmSizeStr));
            
            customer.setBusinessName(txtBusinessName.getText().trim().isEmpty() ? null : txtBusinessName.getText().trim());
            
            boolean success = customerDAO.updateCustomer(customer);
            
            if (success) {
                showSuccess("✅ Customer updated successfully!");
                loadCustomers();
                clearFields();
            }
            
        } catch (SQLException e) {
            showError("Error: " + e.getMessage());
        }
    }
    
    private void deleteCustomer() {
        if (selectedCustomerId == -1) {
            showWarning("Please select a customer to delete!");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Delete this customer?",
            "Confirm",
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                boolean success = customerDAO.deleteCustomer(selectedCustomerId);
                if (success) {
                    showSuccess("✅ Customer deleted!");
                    loadCustomers();
                    clearFields();
                }
            } catch (SQLException e) {
                showError("Error: " + e.getMessage());
            }
        }
    }
    
    private void searchCustomers() {
        String searchTerm = txtSearch.getText().trim();
        if (searchTerm.isEmpty()) {
            loadCustomers();
            return;
        }
        
        try {
            tableModel.setRowCount(0);
            List<RetailCustomer> customers = customerDAO.searchCustomers(searchTerm);
            
            for (RetailCustomer customer : customers) {
                Object[] row = {
                    customer.getCustomerId(),
                    customer.getFirstName(),
                    customer.getLastName(),
                    customer.getEmail(),
                    customer.getPhone(),
                    customer.getNic(),
                    customer.getCity(),
                    customer.getCustomerType()
                };
                tableModel.addRow(row);
            }
            
            showInfo("Found " + customers.size() + " customer(s)");
            
        } catch (SQLException e) {
            showError("Error: " + e.getMessage());
        }
    }
    
    private void clearFields() {
        txtFirstName.setText("");
        txtLastName.setText("");
        txtEmail.setText("");
        txtPhone.setText("");
        txtNic.setText("");
        txtAddress.setText("");
        txtCity.setText("");
        cmbCustomerType.setSelectedIndex(0);
        txtFarmSize.setText("");
        txtBusinessName.setText("");
        txtSearch.setText("");
        selectedCustomerId = -1;
        tblCustomers.clearSelection();
        toggleFields();
    }
    
    private boolean validateInputs() {
        if (Validator.isEmpty(txtFirstName.getText())) {
            showWarning("First name required!");
            return false;
        }
        
        if (Validator.isEmpty(txtLastName.getText())) {
            showWarning("Last name required!");
            return false;
        }
        
        if (!Validator.isValidEmail(txtEmail.getText().trim())) {
            showWarning("Invalid email!");
            return false;
        }
        
        if (!Validator.isValidPhone(txtPhone.getText().trim())) {
            showWarning("Invalid phone!");
            return false;
        }
        
        if (!Validator.isValidNIC(txtNic.getText().trim())) {
            showWarning("Invalid NIC!");
            return false;
        }
        
        String farmSizeStr = txtFarmSize.getText().trim();
        if (!farmSizeStr.isEmpty()) {
            try {
                double farmSize = Double.parseDouble(farmSizeStr);
                if (!Validator.isPositiveNumber(farmSize)) {
                    showWarning("Farm size must be positive!");
                    return false;
                }
            } catch (NumberFormatException e) {
                showWarning("Invalid farm size!");
                return false;
            }
        }
        
        return true;
    }
    
    private void showSuccess(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Success", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void showWarning(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Warning", JOptionPane.WARNING_MESSAGE);
    }
    
    private void showInfo(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Info", JOptionPane.INFORMATION_MESSAGE);
    }
}