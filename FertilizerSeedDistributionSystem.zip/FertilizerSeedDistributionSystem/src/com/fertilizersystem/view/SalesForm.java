package com.fertilizersystem.view;

import com.fertilizersystem.dao.*;
import com.fertilizersystem.model.*;
import com.fertilizersystem.util.Validator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

/**
 * Sales Order Management - MAIN TRANSACTION - 3-COLUMN LAYOUT
 */
public class SalesForm extends JFrame {
    
    private SalesOrderDAO orderDAO;
    private RetailCustomerDAO customerDAO;
    private ProductDAO productDAO;
    private DefaultTableModel tableModel;
    
    private JTable tblOrders;
    private JComboBox<String> cmbCustomer, cmbProduct, cmbPaymentMethod, cmbPaymentStatus, cmbDeliveryStatus;
    private JTextField txtOrderDate, txtDeliveryDate, txtQuantity, txtPricePerUnit;
    private JTextField txtSubtotal, txtDiscountPercent, txtDiscountAmount, txtTotalAmount;
    private JTextField txtDeliveryAddress, txtSearch;
    private JTextArea txtNotes;
    
    private JButton btnCalculate, btnAdd, btnUpdate, btnDelete, btnClear;
    private JButton btnShowAll, btnShowProcessing, btnRefresh, btnBack;
    
    private int selectedOrderId = -1;
    
    public SalesForm() {
        orderDAO = new SalesOrderDAO();
        customerDAO = new RetailCustomerDAO();
        productDAO = new ProductDAO();
        initComponents();
        loadOrders();
        loadCustomers();
        loadProducts();
        setLocationRelativeTo(null);
    }
    
    private void initComponents() {
        setTitle("Sales Order Management ");
        setSize(1500, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        setLayout(null);
        getContentPane().setBackground(new Color(236, 240, 241));
        
        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(null);
        headerPanel.setBackground(new Color(41, 128, 185));
        headerPanel.setBounds(0, 0, 1500, 60);
        add(headerPanel);
        
        JLabel lblTitle = new JLabel(" SALES ORDER MANAGEMENT");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(30, 15, 500, 30);
        headerPanel.add(lblTitle);
        
        btnBack = new JButton("← BACK");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnBack.setBounds(1350, 15, 120, 32);
        btnBack.setBackground(new Color(231, 76, 60));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setBorderPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.addActionListener(e -> dispose());
        headerPanel.add(btnBack);
        
        // LEFT COLUMN - Input Fields
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(null);
        leftPanel.setBackground(Color.WHITE);
        leftPanel.setBounds(20, 80, 420, 700);
        leftPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(41, 128, 185), 2),
            "Order Details",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(44, 62, 80)
        ));
        add(leftPanel);
        
        int yPos = 35;
        int gap = 60;
        
        addLabel(leftPanel, "Customer:", 15, yPos);
        cmbCustomer = new JComboBox<>();
        cmbCustomer.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        cmbCustomer.setBounds(15, yPos + 20, 390, 30);
        leftPanel.add(cmbCustomer);
        
        yPos += gap;
        addLabel(leftPanel, " Product:", 15, yPos);
        cmbProduct = new JComboBox<>();
        cmbProduct.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        cmbProduct.setBounds(15, yPos + 20, 390, 30);
        cmbProduct.addActionListener(e -> updatePricePerUnit());
        leftPanel.add(cmbProduct);
        
        yPos += gap;
        addLabel(leftPanel, "Order Date:", 15, yPos);
        txtOrderDate = addTextField(leftPanel, 15, yPos + 20, 190);
        txtOrderDate.setText(LocalDate.now().toString());
        
        addLabel(leftPanel, "Delivery Date:", 210, yPos);
        txtDeliveryDate = addTextField(leftPanel, 210, yPos + 20, 195);
        
        yPos += gap;
        addLabel(leftPanel, "Quantity:", 15, yPos);
        txtQuantity = addTextField(leftPanel, 15, yPos + 20, 190);
        
        addLabel(leftPanel, "Price/Unit:", 210, yPos);
        txtPricePerUnit = addTextField(leftPanel, 210, yPos + 20, 195);
        txtPricePerUnit.setEditable(false);
        txtPricePerUnit.setBackground(new Color(240, 240, 240));
        
        yPos += gap;
        addLabel(leftPanel, "Subtotal (Rs):", 15, yPos);
        txtSubtotal = addTextField(leftPanel, 15, yPos + 20, 390);
        txtSubtotal.setEditable(false);
        txtSubtotal.setBackground(new Color(255, 255, 200));
        
        yPos += gap;
        addLabel(leftPanel, "Discount %:", 15, yPos);
        txtDiscountPercent = addTextField(leftPanel, 15, yPos + 20, 190);
        txtDiscountPercent.setText("0.0");
        
        addLabel(leftPanel, "Discount Rs:", 210, yPos);
        txtDiscountAmount = addTextField(leftPanel, 210, yPos + 20, 195);
        txtDiscountAmount.setEditable(false);
        txtDiscountAmount.setBackground(new Color(240, 240, 240));
        
        yPos += gap;
        addLabel(leftPanel, " TOTAL (Rs):", 15, yPos);
        txtTotalAmount = addTextField(leftPanel, 15, yPos + 20, 390);
        txtTotalAmount.setEditable(false);
        txtTotalAmount.setBackground(new Color(144, 238, 144));
        txtTotalAmount.setFont(new Font("Segoe UI", Font.BOLD, 14));
        
        yPos += gap;
        addLabel(leftPanel, "Payment Method:", 15, yPos);
        String[] payMethods = {"Cash", "Card", "Bank Transfer", "Credit"};
        cmbPaymentMethod = new JComboBox<>(payMethods);
        cmbPaymentMethod.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        cmbPaymentMethod.setBounds(15, yPos + 20, 190, 30);
        leftPanel.add(cmbPaymentMethod);
        
        addLabel(leftPanel, "Payment:", 210, yPos);
        String[] payStatus = {"PENDING", "PAID", "PARTIAL", "REFUNDED"};
        cmbPaymentStatus = new JComboBox<>(payStatus);
        cmbPaymentStatus.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        cmbPaymentStatus.setBounds(210, yPos + 20, 195, 30);
        leftPanel.add(cmbPaymentStatus);
        
        yPos += gap;
        addLabel(leftPanel, "Delivery Status:", 15, yPos);
        String[] delStatus = {"PROCESSING", "READY", "DISPATCHED", "DELIVERED", "CANCELLED"};
        cmbDeliveryStatus = new JComboBox<>(delStatus);
        cmbDeliveryStatus.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        cmbDeliveryStatus.setBounds(15, yPos + 20, 390, 30);
        leftPanel.add(cmbDeliveryStatus);
        
        yPos += gap;
        addLabel(leftPanel, "Delivery Address:", 15, yPos);
        txtDeliveryAddress = addTextField(leftPanel, 15, yPos + 20, 390);
        
        // MIDDLE COLUMN - Actions
        JPanel middlePanel = new JPanel();
        middlePanel.setLayout(null);
        middlePanel.setBackground(Color.WHITE);
        middlePanel.setBounds(460, 80, 280, 700);
        middlePanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(41, 128, 185), 2),
            "Actions",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(44, 62, 80)
        ));
        add(middlePanel);
        
        int btnY = 40;
        int btnGap = 60;
        
        btnCalculate = createButton(" CALCULATE", 25, btnY, new Color(52, 152, 219), 230);
        btnCalculate.addActionListener(e -> calculateTotal());
        middlePanel.add(btnCalculate);
        
        btnY += btnGap;
        btnAdd = createButton(" CREATE ORDER", 25, btnY, new Color(22, 160, 133), 230);
        btnAdd.addActionListener(e -> addOrder());
        middlePanel.add(btnAdd);
        
        btnY += btnGap;
        btnUpdate = createButton(" UPDATE", 25, btnY, new Color(41, 128, 185), 230);
        btnUpdate.addActionListener(e -> updateOrder());
        middlePanel.add(btnUpdate);
        
        btnY += btnGap;
        btnDelete = createButton("🗑️ DELETE", 25, btnY, new Color(231, 76, 60), 230);
        btnDelete.addActionListener(e -> deleteOrder());
        middlePanel.add(btnDelete);
        
        btnY += btnGap;
        btnClear = createButton(" CLEAR", 25, btnY, new Color(149, 165, 166), 230);
        btnClear.addActionListener(e -> clearFields());
        middlePanel.add(btnClear);
        
        // Notes
        addLabel(middlePanel, "Notes:", 25, 330);
        txtNotes = new JTextArea();
        txtNotes.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        txtNotes.setLineWrap(true);
        txtNotes.setWrapStyleWord(true);
        JScrollPane scrollNotes = new JScrollPane(txtNotes);
        scrollNotes.setBounds(25, 350, 230, 100);
        scrollNotes.setBorder(BorderFactory.createLineBorder(new Color(26, 188, 156), 2));
        middlePanel.add(scrollNotes);
        
        // Info
        JTextArea txtInfo = new JTextArea();
        txtInfo.setEditable(false);
        txtInfo.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        txtInfo.setLineWrap(true);
        txtInfo.setWrapStyleWord(true);
        txtInfo.setBackground(new Color(236, 240, 241));
        txtInfo.setText(" SALES INFO:\n\n" +
                       "• Select customer & product\n" +
                       "• Enter quantity\n" +
                       "• Click CALCULATE\n" +
                       "• Stock auto-reduced\n" +
                       "• Dates: YYYY-MM-DD");
        JScrollPane scrollInfo = new JScrollPane(txtInfo);
        scrollInfo.setBounds(25, 470, 230, 210);
        scrollInfo.setBorder(BorderFactory.createLineBorder(new Color(26, 188, 156), 1));
        middlePanel.add(scrollInfo);
        
        // RIGHT COLUMN - Table
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(null);
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setBounds(760, 80, 720, 700);
        rightPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(41, 128, 185), 2),
            "Sales Orders",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(44, 62, 80)
        ));
        add(rightPanel);
        
        // Filter buttons
        JLabel lblFilter = new JLabel("Filter:");
        lblFilter.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblFilter.setBounds(15, 35, 60, 30);
        rightPanel.add(lblFilter);
        
        btnShowAll = createButton("ALL", 70, 35, new Color(52, 152, 219), 80);
        btnShowAll.addActionListener(e -> loadOrders());
        rightPanel.add(btnShowAll);
        
        btnShowProcessing = createButton("PROCESSING", 160, 35, new Color(241, 196, 15), 120);
        btnShowProcessing.addActionListener(e -> loadProcessingOrders());
        rightPanel.add(btnShowProcessing);
        
        btnRefresh = createButton(" REFRESH", 600, 35, new Color(26, 188, 156), 105);
        btnRefresh.addActionListener(e -> loadOrders());
        rightPanel.add(btnRefresh);
        
        // Table
        String[] columns = {"ID", "Customer", "Product", "Order Date", "Quantity", "Total (Rs)", "Payment", "Delivery"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tblOrders = new JTable(tableModel);
        tblOrders.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        tblOrders.setRowHeight(26);
        tblOrders.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 10));
        tblOrders.getTableHeader().setBackground(new Color(41, 128, 185));
        tblOrders.getTableHeader().setForeground(Color.WHITE);
        tblOrders.setSelectionBackground(new Color(52, 152, 219));
        tblOrders.setSelectionForeground(Color.WHITE);
        
        tblOrders.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedOrder();
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(tblOrders);
        scrollPane.setBounds(15, 80, 690, 605);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(41, 128, 185), 1));
        rightPanel.add(scrollPane);
    }
    
    private void addLabel(JPanel panel, String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 11));
        label.setForeground(new Color(44, 62, 80));
        label.setBounds(x, y, 300, 16);
        panel.add(label);
    }
    
    private JTextField addTextField(JPanel panel, int x, int y, int width) {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        field.setBounds(x, y, width, 28);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(26, 188, 156), 2),
            BorderFactory.createEmptyBorder(3, 8, 3, 8)
        ));
        panel.add(field);
        return field;
    }
    
    private JButton createButton(String text, int x, int y, Color color, int width) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 11));
        btn.setBounds(x, y, width, 38);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(color);
            }
        });
        
        return btn;
    }
    
    private void loadCustomers() {
        try {
            cmbCustomer.removeAllItems();
            List<RetailCustomer> customers = customerDAO.getAllCustomers();
            for (RetailCustomer customer : customers) {
                cmbCustomer.addItem(customer.getCustomerId() + " - " + customer.getFullName() + " (" + customer.getCustomerType() + ")");
            }
        } catch (SQLException e) {
            showError("Error loading customers: " + e.getMessage());
        }
    }
    
    private void loadProducts() {
        try {
            cmbProduct.removeAllItems();
            List<Product> products = productDAO.getAvailableProducts();
            for (Product product : products) {
                cmbProduct.addItem(product.getProductId() + " - " + product.getProductName() + " (Rs." + String.format("%.2f", product.getPricePerUnit()) + "/" + product.getUnitType() + ")");
            }
        } catch (SQLException e) {
            showError("Error loading products: " + e.getMessage());
        }
    }
    
    private void updatePricePerUnit() {
        String selected = (String) cmbProduct.getSelectedItem();
        if (selected != null) {
            try {
                int productId = Integer.parseInt(selected.split(" - ")[0]);
                Product product = productDAO.getProductById(productId);
                if (product != null) {
                    txtPricePerUnit.setText(String.format("%.2f", product.getPricePerUnit()));
                }
            } catch (Exception e) {
                // Ignore
            }
        }
    }
    
    private void calculateTotal() {
        try {
            int quantity = Integer.parseInt(txtQuantity.getText().trim());
            double pricePerUnit = Double.parseDouble(txtPricePerUnit.getText().trim());
            double discountPercent = Double.parseDouble(txtDiscountPercent.getText().trim());
            
            double subtotal = quantity * pricePerUnit;
            double discountAmount = subtotal * (discountPercent / 100.0);
            double total = subtotal - discountAmount;
            
            txtSubtotal.setText(String.format("%.2f", subtotal));
            txtDiscountAmount.setText(String.format("%.2f", discountAmount));
            txtTotalAmount.setText(String.format("%.2f", total));
            
            showInfo("✅ Total calculated: Rs." + String.format("%.2f", total));
            
        } catch (NumberFormatException e) {
            showWarning("Please enter valid quantity and discount!");
        }
    }
    
    private void loadOrders() {
        try {
            tableModel.setRowCount(0);
            List<SalesOrder> orders = orderDAO.getAllOrders();
            
            for (SalesOrder order : orders) {
                Object[] row = {
                    order.getOrderId(),
                    order.getCustomerName(),
                    order.getProductName(),
                    order.getOrderDate(),
                    order.getQuantity() + " " + order.getUnitType(),
                    "Rs." + String.format("%.2f", order.getTotalAmount()),
                    order.getPaymentStatus(),
                    order.getDeliveryStatus()
                };
                tableModel.addRow(row);
            }
            
        } catch (SQLException e) {
            showError("Error loading orders: " + e.getMessage());
        }
    }
    
    private void loadProcessingOrders() {
        try {
            tableModel.setRowCount(0);
            List<SalesOrder> orders = orderDAO.getProcessingOrders();
            
            for (SalesOrder order : orders) {
                Object[] row = {
                    order.getOrderId(),
                    order.getCustomerName(),
                    order.getProductName(),
                    order.getOrderDate(),
                    order.getQuantity() + " " + order.getUnitType(),
                    "Rs." + String.format("%.2f", order.getTotalAmount()),
                    order.getPaymentStatus(),
                    order.getDeliveryStatus()
                };
                tableModel.addRow(row);
            }
            
        } catch (SQLException e) {
            showError("Error: " + e.getMessage());
        }
    }
    
    private void loadSelectedOrder() {
        int selectedRow = tblOrders.getSelectedRow();
        if (selectedRow >= 0) {
            selectedOrderId = (int) tableModel.getValueAt(selectedRow, 0);
            
            try {
                SalesOrder order = orderDAO.getOrderById(selectedOrderId);
                if (order != null) {
                    txtOrderDate.setText(order.getOrderDate().toString());
                    txtDeliveryDate.setText(order.getDeliveryDate().toString());
                    txtQuantity.setText(String.valueOf(order.getQuantity()));
                    txtPricePerUnit.setText(String.format("%.2f", order.getPricePerUnit()));
                    txtSubtotal.setText(String.format("%.2f", order.getSubtotal()));
                    txtDiscountPercent.setText(String.format("%.2f", order.getDiscountPercent()));
                    txtDiscountAmount.setText(String.format("%.2f", order.getDiscountAmount()));
                    txtTotalAmount.setText(String.format("%.2f", order.getTotalAmount()));
                    cmbPaymentMethod.setSelectedItem(order.getPaymentMethod());
                    cmbPaymentStatus.setSelectedItem(order.getPaymentStatus());
                    cmbDeliveryStatus.setSelectedItem(order.getDeliveryStatus());
                    txtDeliveryAddress.setText(order.getDeliveryAddress());
                    txtNotes.setText(order.getNotes());
                }
            } catch (SQLException e) {
                showError("Error: " + e.getMessage());
            }
        }
    }
    
    private void addOrder() {
        if (!validateInputs()) return;
        
        try {
            String custStr = (String) cmbCustomer.getSelectedItem();
            int customerId = Integer.parseInt(custStr.split(" - ")[0]);
            
            String prodStr = (String) cmbProduct.getSelectedItem();
            int productId = Integer.parseInt(prodStr.split(" - ")[0]);
            
            SalesOrder order = new SalesOrder();
            order.setCustomerId(customerId);
            order.setProductId(productId);
            order.setOrderDate(Date.valueOf(txtOrderDate.getText().trim()));
            order.setDeliveryDate(Date.valueOf(txtDeliveryDate.getText().trim()));
            order.setQuantity(Integer.parseInt(txtQuantity.getText().trim()));
            order.setUnitType(productDAO.getProductById(productId).getUnitType());
            order.setPricePerUnit(Double.parseDouble(txtPricePerUnit.getText().trim()));
            order.setSubtotal(Double.parseDouble(txtSubtotal.getText().trim()));
            order.setDiscountPercent(Double.parseDouble(txtDiscountPercent.getText().trim()));
            order.setDiscountAmount(Double.parseDouble(txtDiscountAmount.getText().trim()));
            order.setTotalAmount(Double.parseDouble(txtTotalAmount.getText().trim()));
            order.setPaymentMethod((String) cmbPaymentMethod.getSelectedItem());
            order.setPaymentStatus((String) cmbPaymentStatus.getSelectedItem());
            order.setDeliveryStatus((String) cmbDeliveryStatus.getSelectedItem());
            order.setDeliveryAddress(txtDeliveryAddress.getText().trim());
            order.setNotes(txtNotes.getText().trim());
            
            boolean success = orderDAO.addOrder(order);
            
            if (success) {
                // Reduce stock
                int quantity = Integer.parseInt(txtQuantity.getText().trim());
                productDAO.reduceStock(productId, quantity);
                
                // Update customer total purchases
                double total = Double.parseDouble(txtTotalAmount.getText().trim());
                customerDAO.updateTotalPurchases(customerId, total);
                
                showSuccess("✅ Order created successfully!\n\nTotal: Rs." + txtTotalAmount.getText());
                loadOrders();
                loadProducts(); // Refresh product list
                clearFields();
            }
            
        } catch (Exception e) {
            showError("Error: " + e.getMessage());
        }
    }
    
    private void updateOrder() {
        if (selectedOrderId == -1) {
            showWarning("Please select an order to update!");
            return;
        }
        
        if (!validateInputs()) return;
        
        try {
            String custStr = (String) cmbCustomer.getSelectedItem();
            int customerId = Integer.parseInt(custStr.split(" - ")[0]);
            
            String prodStr = (String) cmbProduct.getSelectedItem();
            int productId = Integer.parseInt(prodStr.split(" - ")[0]);
            
            SalesOrder order = new SalesOrder();
            order.setOrderId(selectedOrderId);
            order.setCustomerId(customerId);
            order.setProductId(productId);
            order.setOrderDate(Date.valueOf(txtOrderDate.getText().trim()));
            order.setDeliveryDate(Date.valueOf(txtDeliveryDate.getText().trim()));
            order.setQuantity(Integer.parseInt(txtQuantity.getText().trim()));
            order.setUnitType(productDAO.getProductById(productId).getUnitType());
            order.setPricePerUnit(Double.parseDouble(txtPricePerUnit.getText().trim()));
            order.setSubtotal(Double.parseDouble(txtSubtotal.getText().trim()));
            order.setDiscountPercent(Double.parseDouble(txtDiscountPercent.getText().trim()));
            order.setDiscountAmount(Double.parseDouble(txtDiscountAmount.getText().trim()));
            order.setTotalAmount(Double.parseDouble(txtTotalAmount.getText().trim()));
            order.setPaymentMethod((String) cmbPaymentMethod.getSelectedItem());
            order.setPaymentStatus((String) cmbPaymentStatus.getSelectedItem());
            order.setDeliveryStatus((String) cmbDeliveryStatus.getSelectedItem());
            order.setDeliveryAddress(txtDeliveryAddress.getText().trim());
            order.setNotes(txtNotes.getText().trim());
            
            boolean success = orderDAO.updateOrder(order);
            
            if (success) {
                showSuccess("✅ Order updated successfully!");
                loadOrders();
                clearFields();
            }
            
        } catch (Exception e) {
            showError("Error: " + e.getMessage());
        }
    }
    
    private void deleteOrder() {
        if (selectedOrderId == -1) {
            showWarning("Please select an order to delete!");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Delete this order?",
            "Confirm",
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                boolean success = orderDAO.deleteOrder(selectedOrderId);
                if (success) {
                    showSuccess("✅ Order deleted!");
                    loadOrders();
                    clearFields();
                }
            } catch (SQLException e) {
                showError("Error: " + e.getMessage());
            }
        }
    }
    
    private void clearFields() {
        if (cmbCustomer.getItemCount() > 0) cmbCustomer.setSelectedIndex(0);
        if (cmbProduct.getItemCount() > 0) cmbProduct.setSelectedIndex(0);
        txtOrderDate.setText(LocalDate.now().toString());
        txtDeliveryDate.setText("");
        txtQuantity.setText("");
        txtPricePerUnit.setText("");
        txtSubtotal.setText("");
        txtDiscountPercent.setText("0.0");
        txtDiscountAmount.setText("");
        txtTotalAmount.setText("");
        cmbPaymentMethod.setSelectedIndex(0);
        cmbPaymentStatus.setSelectedIndex(0);
        cmbDeliveryStatus.setSelectedIndex(0);
        txtDeliveryAddress.setText("");
        txtNotes.setText("");
        selectedOrderId = -1;
        tblOrders.clearSelection();
    }
    
    private boolean validateInputs() {
        if (cmbCustomer.getSelectedItem() == null) {
            showWarning("Please select a customer!");
            return false;
        }
        
        if (cmbProduct.getSelectedItem() == null) {
            showWarning("Please select a product!");
            return false;
        }
        
        if (Validator.isEmpty(txtTotalAmount.getText())) {
            showWarning("Please calculate total first!");
            btnCalculate.requestFocus();
            return false;
        }
        
        try {
            Date.valueOf(txtOrderDate.getText().trim());
        } catch (Exception e) {
            showWarning("Invalid order date!");
            return false;
        }
        
        try {
            Date.valueOf(txtDeliveryDate.getText().trim());
        } catch (Exception e) {
            showWarning("Invalid delivery date!");
            return false;
        }
        
        return true;
    }
    
    private void showSuccess(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Success", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void showWarning(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Warning", JOptionPane.WARNING_MESSAGE);
    }
    
    private void showInfo(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Info", JOptionPane.INFORMATION_MESSAGE);
    }
}