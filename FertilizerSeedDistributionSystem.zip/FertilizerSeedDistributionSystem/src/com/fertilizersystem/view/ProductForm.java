package com.fertilizersystem.view;

import com.fertilizersystem.dao.ProductDAO;
import com.fertilizersystem.dao.FertilizerSupplierDAO;
import com.fertilizersystem.model.Product;
import com.fertilizersystem.model.FertilizerSupplier;
import com.fertilizersystem.util.Validator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

/**
 * Product Management Form - 3-COLUMN HORIZONTAL LAYOUT
 */
public class ProductForm extends JFrame {
    
    private ProductDAO productDAO;
    private FertilizerSupplierDAO supplierDAO;
    private DefaultTableModel tableModel;
    
    private JTable tblProducts;
    private JComboBox<String> cmbSupplier, cmbProductType, cmbCategory, cmbUnitType;
    private JTextField txtProductName, txtCropType, txtPricePerUnit;
    private JTextField txtStockQuantity, txtReorderLevel, txtExpiryDate, txtManufacturer;
    private JTextField txtSearch;
    
    private JButton btnAdd, btnUpdate, btnDelete, btnClear, btnSearch, btnRefresh, btnBack;
    
    private int selectedProductId = -1;
    
    public ProductForm() {
        productDAO = new ProductDAO();
        supplierDAO = new FertilizerSupplierDAO();
        initComponents();
        loadProducts();
        loadSuppliers();
        setLocationRelativeTo(null);
    }
    
    private void initComponents() {
        setTitle("Product Management ");
        setSize(1500, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        setLayout(null);
        getContentPane().setBackground(new Color(236, 240, 241));
        
        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(null);
        headerPanel.setBackground(new Color(41, 128, 185));
        headerPanel.setBounds(0, 0, 1500, 60);
        add(headerPanel);
        
        JLabel lblTitle = new JLabel(" PRODUCT MANAGEMENT");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(30, 15, 400, 30);
        headerPanel.add(lblTitle);
        
        btnBack = new JButton("← BACK");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnBack.setBounds(1350, 15, 120, 32);
        btnBack.setBackground(new Color(231, 76, 60));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setBorderPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.addActionListener(e -> dispose());
        headerPanel.add(btnBack);
        
        // LEFT COLUMN - Input Fields
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(null);
        leftPanel.setBackground(Color.WHITE);
        leftPanel.setBounds(20, 80, 420, 700);
        leftPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(41, 128, 185), 2),
            "Product Details",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(44, 62, 80)
        ));
        add(leftPanel);
        
        int yPos = 35;
        int gap = 65;
        
        addLabel(leftPanel, "Supplier:", 15, yPos);
        cmbSupplier = new JComboBox<>();
        cmbSupplier.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cmbSupplier.setBounds(15, yPos + 22, 390, 32);
        leftPanel.add(cmbSupplier);
        
        yPos += gap;
        addLabel(leftPanel, "Product Name:", 15, yPos);
        txtProductName = addTextField(leftPanel, 15, yPos + 22, 390);
        
        yPos += gap;
        addLabel(leftPanel, "Product Type:", 15, yPos);
        String[] types = {"Fertilizer", "Seed", "Pesticide", "Growth Supplement"};
        cmbProductType = new JComboBox<>(types);
        cmbProductType.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cmbProductType.setBounds(15, yPos + 22, 390, 32);
        leftPanel.add(cmbProductType);
        
        yPos += gap;
        addLabel(leftPanel, "Category:", 15, yPos);
        String[] categories = {"Organic", "Chemical", "Hybrid", "Natural", "Synthetic"};
        cmbCategory = new JComboBox<>(categories);
        cmbCategory.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cmbCategory.setBounds(15, yPos + 22, 390, 32);
        leftPanel.add(cmbCategory);
        
        yPos += gap;
        addLabel(leftPanel, "Crop Type:", 15, yPos);
        txtCropType = addTextField(leftPanel, 15, yPos + 22, 390);
        
        yPos += gap;
        addLabel(leftPanel, "Unit Type:", 15, yPos);
        String[] units = {"KG", "Liter", "Pack", "Bag"};
        cmbUnitType = new JComboBox<>(units);
        cmbUnitType.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cmbUnitType.setBounds(15, yPos + 22, 390, 32);
        leftPanel.add(cmbUnitType);
        
        yPos += gap;
        addLabel(leftPanel, "Price per Unit (Rs):", 15, yPos);
        txtPricePerUnit = addTextField(leftPanel, 15, yPos + 22, 390);
        
        yPos += gap;
        addLabel(leftPanel, "Stock Quantity:", 15, yPos);
        txtStockQuantity = addTextField(leftPanel, 15, yPos + 22, 190);
        
        addLabel(leftPanel, "Reorder Level:", 210, yPos);
        txtReorderLevel = addTextField(leftPanel, 210, yPos + 22, 195);
        
        yPos += gap;
        addLabel(leftPanel, "Expiry Date (YYYY-MM-DD):", 15, yPos);
        txtExpiryDate = addTextField(leftPanel, 15, yPos + 22, 390);
        
        yPos += gap;
        addLabel(leftPanel, "Manufacturer:", 15, yPos);
        txtManufacturer = addTextField(leftPanel, 15, yPos + 22, 390);
        
        // MIDDLE COLUMN - Actions
        JPanel middlePanel = new JPanel();
        middlePanel.setLayout(null);
        middlePanel.setBackground(Color.WHITE);
        middlePanel.setBounds(460, 80, 280, 700);
        middlePanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(41, 128, 185), 2),
            "Actions",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(44, 62, 80)
        ));
        add(middlePanel);
        
        int btnY = 40;
        int btnGap = 60;
        
        btnAdd = createButton(" ADD", 25, btnY, new Color(22, 160, 133), 230);
        btnAdd.addActionListener(e -> addProduct());
        middlePanel.add(btnAdd);
        
        btnY += btnGap;
        btnUpdate = createButton("UPDATE", 25, btnY, new Color(41, 128, 185), 230);
        btnUpdate.addActionListener(e -> updateProduct());
        middlePanel.add(btnUpdate);
        
        btnY += btnGap;
        btnDelete = createButton("🗑️ DELETE", 25, btnY, new Color(231, 76, 60), 230);
        btnDelete.addActionListener(e -> deleteProduct());
        middlePanel.add(btnDelete);
        
        btnY += btnGap;
        btnClear = createButton(" CLEAR", 25, btnY, new Color(149, 165, 166), 230);
        btnClear.addActionListener(e -> clearFields());
        middlePanel.add(btnClear);
        
        // Info Panel
        JTextArea txtInfo = new JTextArea();
        txtInfo.setEditable(false);
        txtInfo.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        txtInfo.setLineWrap(true);
        txtInfo.setWrapStyleWord(true);
        txtInfo.setBackground(new Color(236, 240, 241));
        txtInfo.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        txtInfo.setText(" PRODUCT INFO:\n\n" +
                       "• Select supplier first\n" +
                       "• All prices in Rs.\n" +
                       "• Stock tracks inventory\n" +
                       "• Reorder level for alerts\n" +
                       "• Expiry: YYYY-MM-DD format");
        
        JScrollPane scrollInfo = new JScrollPane(txtInfo);
        scrollInfo.setBounds(25, 280, 230, 400);
        scrollInfo.setBorder(BorderFactory.createLineBorder(new Color(26, 188, 156), 1));
        middlePanel.add(scrollInfo);
        
        // RIGHT COLUMN - Table
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(null);
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setBounds(760, 80, 720, 700);
        rightPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(41, 128, 185), 2),
            "Product Records",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(44, 62, 80)
        ));
        add(rightPanel);
        
        // Search
        JLabel lblSearch = new JLabel(" Search:");
        lblSearch.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblSearch.setBounds(15, 35, 80, 30);
        rightPanel.add(lblSearch);
        
        txtSearch = new JTextField();
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtSearch.setBounds(95, 35, 390, 30);
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(26, 188, 156), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        rightPanel.add(txtSearch);
        
        btnSearch = createButton("SEARCH", 500, 35, new Color(41, 128, 185), 100);
        btnSearch.addActionListener(e -> searchProducts());
        rightPanel.add(btnSearch);
        
        btnRefresh = createButton("REFRESH", 610, 35, new Color(26, 188, 156), 95);
        btnRefresh.addActionListener(e -> loadProducts());
        rightPanel.add(btnRefresh);
        
        // Table
        String[] columns = {"ID", "Product", "Type", "Category", "Unit", "Price", "Stock", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tblProducts = new JTable(tableModel);
        tblProducts.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        tblProducts.setRowHeight(26);
        tblProducts.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 11));
        tblProducts.getTableHeader().setBackground(new Color(41, 128, 185));
        tblProducts.getTableHeader().setForeground(Color.WHITE);
        tblProducts.setSelectionBackground(new Color(52, 152, 219));
        tblProducts.setSelectionForeground(Color.WHITE);
        
        tblProducts.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedProduct();
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(tblProducts);
        scrollPane.setBounds(15, 80, 690, 605);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(41, 128, 185), 1));
        rightPanel.add(scrollPane);
    }
    
    private void addLabel(JPanel panel, String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(new Color(44, 62, 80));
        label.setBounds(x, y, 300, 18);
        panel.add(label);
    }
    
    private JTextField addTextField(JPanel panel, int x, int y, int width) {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setBounds(x, y, width, 32);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(26, 188, 156), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panel.add(field);
        return field;
    }
    
    private JButton createButton(String text, int x, int y, Color color, int width) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBounds(x, y, width, 40);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(color);
            }
        });
        
        return btn;
    }
    
    private void loadSuppliers() {
        try {
            cmbSupplier.removeAllItems();
            List<FertilizerSupplier> suppliers = supplierDAO.getAllSuppliers();
            for (FertilizerSupplier supplier : suppliers) {
                cmbSupplier.addItem(supplier.getSupplierId() + " - " + supplier.getCompanyName());
            }
        } catch (SQLException e) {
            showError("Error loading suppliers: " + e.getMessage());
        }
    }
    
    private void loadProducts() {
        try {
            tableModel.setRowCount(0);
            List<Product> products = productDAO.getAllProducts();
            
            for (Product product : products) {
                Object[] row = {
                    product.getProductId(),
                    product.getProductName(),
                    product.getProductType(),
                    product.getCategory(),
                    product.getUnitType(),
                    "Rs." + String.format("%.2f", product.getPricePerUnit()),
                    product.getStockQuantity(),
                    product.getStatus()
                };
                tableModel.addRow(row);
            }
            
        } catch (SQLException e) {
            showError("Error loading products: " + e.getMessage());
        }
    }
    
    private void loadSelectedProduct() {
        int selectedRow = tblProducts.getSelectedRow();
        if (selectedRow >= 0) {
            selectedProductId = (int) tableModel.getValueAt(selectedRow, 0);
            
            try {
                Product product = productDAO.getProductById(selectedProductId);
                if (product != null) {
                    // Set supplier
                    for (int i = 0; i < cmbSupplier.getItemCount(); i++) {
                        if (cmbSupplier.getItemAt(i).startsWith(product.getSupplierId() + " - ")) {
                            cmbSupplier.setSelectedIndex(i);
                            break;
                        }
                    }
                    
                    txtProductName.setText(product.getProductName());
                    cmbProductType.setSelectedItem(product.getProductType());
                    cmbCategory.setSelectedItem(product.getCategory());
                    txtCropType.setText(product.getCropType());
                    cmbUnitType.setSelectedItem(product.getUnitType());
                    txtPricePerUnit.setText(String.format("%.2f", product.getPricePerUnit()));
                    txtStockQuantity.setText(String.valueOf(product.getStockQuantity()));
                    txtReorderLevel.setText(String.valueOf(product.getReorderLevel()));
                    txtExpiryDate.setText(product.getExpiryDate() != null ? product.getExpiryDate().toString() : "");
                    txtManufacturer.setText(product.getManufacturer());
                }
            } catch (SQLException e) {
                showError("Error loading product: " + e.getMessage());
            }
        }
    }
    
    private void addProduct() {
        if (!validateInputs()) return;
        
        try {
            String supplierStr = (String) cmbSupplier.getSelectedItem();
            int supplierId = Integer.parseInt(supplierStr.split(" - ")[0]);
            
            Product product = new Product();
            product.setSupplierId(supplierId);
            product.setProductName(txtProductName.getText().trim());
            product.setProductType((String) cmbProductType.getSelectedItem());
            product.setCategory((String) cmbCategory.getSelectedItem());
            product.setCropType(txtCropType.getText().trim());
            product.setUnitType((String) cmbUnitType.getSelectedItem());
            product.setPricePerUnit(Double.parseDouble(txtPricePerUnit.getText().trim()));
            product.setStockQuantity(Integer.parseInt(txtStockQuantity.getText().trim()));
            product.setReorderLevel(Integer.parseInt(txtReorderLevel.getText().trim()));
            
            String expiryStr = txtExpiryDate.getText().trim();
            if (!expiryStr.isEmpty()) {
                product.setExpiryDate(Date.valueOf(expiryStr));
            }
            
            product.setManufacturer(txtManufacturer.getText().trim());
            product.setDescription("");
            product.setStatus("AVAILABLE");
            
            boolean success = productDAO.addProduct(product);
            
            if (success) {
                showSuccess("✅ Product added successfully!");
                loadProducts();
                clearFields();
            }
            
        } catch (Exception e) {
            showError("Error: " + e.getMessage());
        }
    }
    
    private void updateProduct() {
        if (selectedProductId == -1) {
            showWarning("Please select a product to update!");
            return;
        }
        
        if (!validateInputs()) return;
        
        try {
            String supplierStr = (String) cmbSupplier.getSelectedItem();
            int supplierId = Integer.parseInt(supplierStr.split(" - ")[0]);
            
            Product product = new Product();
            product.setProductId(selectedProductId);
            product.setSupplierId(supplierId);
            product.setProductName(txtProductName.getText().trim());
            product.setProductType((String) cmbProductType.getSelectedItem());
            product.setCategory((String) cmbCategory.getSelectedItem());
            product.setCropType(txtCropType.getText().trim());
            product.setUnitType((String) cmbUnitType.getSelectedItem());
            product.setPricePerUnit(Double.parseDouble(txtPricePerUnit.getText().trim()));
            product.setStockQuantity(Integer.parseInt(txtStockQuantity.getText().trim()));
            product.setReorderLevel(Integer.parseInt(txtReorderLevel.getText().trim()));
            
            String expiryStr = txtExpiryDate.getText().trim();
            if (!expiryStr.isEmpty()) {
                product.setExpiryDate(Date.valueOf(expiryStr));
            }
            
            product.setManufacturer(txtManufacturer.getText().trim());
            product.setDescription("");
            product.setStatus("AVAILABLE");
            
            boolean success = productDAO.updateProduct(product);
            
            if (success) {
                showSuccess("✅ Product updated successfully!");
                loadProducts();
                clearFields();
            }
            
        } catch (Exception e) {
            showError("Error: " + e.getMessage());
        }
    }
    
    private void deleteProduct() {
        if (selectedProductId == -1) {
            showWarning("Please select a product to delete!");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Delete this product?",
            "Confirm",
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                boolean success = productDAO.deleteProduct(selectedProductId);
                if (success) {
                    showSuccess("✅ Product deleted!");
                    loadProducts();
                    clearFields();
                }
            } catch (SQLException e) {
                showError("Error: " + e.getMessage());
            }
        }
    }
    
    private void searchProducts() {
        String searchTerm = txtSearch.getText().trim();
        if (searchTerm.isEmpty()) {
            loadProducts();
            return;
        }
        
        try {
            tableModel.setRowCount(0);
            List<Product> products = productDAO.searchProducts(searchTerm);
            
            for (Product product : products) {
                Object[] row = {
                    product.getProductId(),
                    product.getProductName(),
                    product.getProductType(),
                    product.getCategory(),
                    product.getUnitType(),
                    "Rs." + String.format("%.2f", product.getPricePerUnit()),
                    product.getStockQuantity(),
                    product.getStatus()
                };
                tableModel.addRow(row);
            }
            
            showInfo("Found " + products.size() + " product(s)");
            
        } catch (SQLException e) {
            showError("Error: " + e.getMessage());
        }
    }
    
    private void clearFields() {
        if (cmbSupplier.getItemCount() > 0) cmbSupplier.setSelectedIndex(0);
        txtProductName.setText("");
        cmbProductType.setSelectedIndex(0);
        cmbCategory.setSelectedIndex(0);
        txtCropType.setText("");
        cmbUnitType.setSelectedIndex(0);
        txtPricePerUnit.setText("");
        txtStockQuantity.setText("");
        txtReorderLevel.setText("");
        txtExpiryDate.setText("");
        txtManufacturer.setText("");
        txtSearch.setText("");
        selectedProductId = -1;
        tblProducts.clearSelection();
    }
    
    private boolean validateInputs() {
        if (cmbSupplier.getSelectedItem() == null) {
            showWarning("Please select a supplier!");
            return false;
        }
        
        if (Validator.isEmpty(txtProductName.getText())) {
            showWarning("Product name required!");
            return false;
        }
        
        try {
            double price = Double.parseDouble(txtPricePerUnit.getText().trim());
            if (!Validator.isPositiveNumber(price)) {
                showWarning("Price must be positive!");
                return false;
            }
        } catch (NumberFormatException e) {
            showWarning("Invalid price!");
            return false;
        }
        
        try {
            int stock = Integer.parseInt(txtStockQuantity.getText().trim());
            if (!Validator.isNonNegativeInteger(stock)) {
                showWarning("Stock cannot be negative!");
                return false;
            }
        } catch (NumberFormatException e) {
            showWarning("Invalid stock!");
            return false;
        }
        
        return true;
    }
    
    private void showSuccess(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Success", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void showWarning(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Warning", JOptionPane.WARNING_MESSAGE);
    }
    
    private void showInfo(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Info", JOptionPane.INFORMATION_MESSAGE);
    }
}