package com.fertilizersystem.view;

import javax.swing.*;
import java.awt.*;

/**
 * Login Form - Ocean Blue Theme
 */
public class LoginForm extends JFrame {
    
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    private JButton btnExit;
    
    public LoginForm() {
        initComponents();
        setLocationRelativeTo(null);
    }
    
    private void initComponents() {
        setTitle("Fertilizer & Seed Distribution System - Login");
        setSize(600, 570);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLayout(null);
        
        // Background - Light Blue-Gray
        getContentPane().setBackground(new Color(236, 240, 241));
        
        // Main Panel - Ocean Blue gradient
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setBackground(new Color(245, 248, 250));
        mainPanel.setBounds(75, 60, 450, 420);
        mainPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(41, 128, 185), 3),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        add(mainPanel);
        
        // Icon
        JLabel lblIcon = new JLabel("🌱", SwingConstants.CENTER);
        lblIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 50));
        lblIcon.setBounds(0, 20, 410, 60);
        mainPanel.add(lblIcon);
        
        // Title
        JLabel lblTitle = new JLabel(" FERTILIZER & SEED DISTRIBUTIONS");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setForeground(new Color(44, 62, 80));
        lblTitle.setBounds(0, 85, 410, 35);
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        mainPanel.add(lblTitle);
        
        // Subtitle
        JLabel lblSubtitle = new JLabel("Agricultural Supply Management");
        lblSubtitle.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        lblSubtitle.setForeground(new Color(41, 128, 185));
        lblSubtitle.setBounds(0, 120, 410, 25);
        lblSubtitle.setHorizontalAlignment(SwingConstants.CENTER);
        mainPanel.add(lblSubtitle);
        
        // Username Label
        JLabel lblUsername = new JLabel(" Username");
        lblUsername.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblUsername.setForeground(new Color(44, 62, 80));
        lblUsername.setBounds(50, 165, 150, 25);
        mainPanel.add(lblUsername);
        
        // Username TextField
        txtUsername = new JTextField("admin");
        txtUsername.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        txtUsername.setBounds(50, 195, 310, 45);
        txtUsername.setBackground(new Color(255, 255, 255));
        txtUsername.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(26, 188, 156), 2),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        mainPanel.add(txtUsername);
        
        // Password Label
        JLabel lblPassword = new JLabel(" Password");
        lblPassword.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblPassword.setForeground(new Color(44, 62, 80));
        lblPassword.setBounds(50, 250, 150, 25);
        mainPanel.add(lblPassword);
        
        // Password Field
        txtPassword = new JPasswordField("admin123");
        txtPassword.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        txtPassword.setBounds(50, 280, 310, 45);
        txtPassword.setBackground(new Color(255, 255, 255));
        txtPassword.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(26, 188, 156), 2),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        mainPanel.add(txtPassword);
        
        // Login Button - Ocean Blue
        btnLogin = new JButton(" LOGIN");
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btnLogin.setBounds(50, 340, 155, 50);
        btnLogin.setBackground(new Color(41, 128, 185));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setBorderPainted(false);
        btnLogin.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLogin.addActionListener(e -> handleLogin());
        btnLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnLogin.setBackground(new Color(52, 152, 219));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnLogin.setBackground(new Color(41, 128, 185));
            }
        });
        mainPanel.add(btnLogin);
        
        // Exit Button - Navy
        btnExit = new JButton("EXIT");
        btnExit.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btnExit.setBounds(215, 340, 145, 50);
        btnExit.setBackground(new Color(44, 62, 80));
        btnExit.setForeground(Color.WHITE);
        btnExit.setFocusPainted(false);
        btnExit.setBorderPainted(false);
        btnExit.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnExit.addActionListener(e -> handleExit());
        btnExit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnExit.setBackground(new Color(52, 73, 94));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnExit.setBackground(new Color(44, 62, 80));
            }
        });
        mainPanel.add(btnExit);
    }
    
    private void handleLogin() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();
        
        if (username.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please enter username!", 
                "Validation Error", 
                JOptionPane.WARNING_MESSAGE);
            txtUsername.requestFocus();
            return;
        }
        
        if (password.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please enter password!", 
                "Validation Error", 
                JOptionPane.WARNING_MESSAGE);
            txtPassword.requestFocus();
            return;
        }
        
        if (username.equals("admin") && password.equals("admin123")) {
            JOptionPane.showMessageDialog(this, 
                "🌱 Login Successful!\nWelcome to Fertilizer & Seed Distribution System!", 
                "Success", 
                JOptionPane.INFORMATION_MESSAGE);
            
            this.dispose();
            DashboardForm dashboard = new DashboardForm();
            dashboard.setVisible(true);
            
        } else {
            JOptionPane.showMessageDialog(this, 
                "❌ Invalid username or password!\n\nDefault credentials:\nUsername: admin\nPassword: admin123", 
                "Login Failed", 
                JOptionPane.ERROR_MESSAGE);
            txtPassword.setText("");
            txtUsername.requestFocus();
        }
    }
    
    private void handleExit() {
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to exit?", 
            "Confirm Exit", 
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }
    
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> new LoginForm().setVisible(true));
    }
}