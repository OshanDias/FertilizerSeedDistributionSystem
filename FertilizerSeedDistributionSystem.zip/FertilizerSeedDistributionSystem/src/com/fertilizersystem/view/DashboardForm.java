package com.fertilizersystem.view;

import com.fertilizersystem.controller.ReportController;
import com.fertilizersystem.dao.*;
import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

/**
 * Dashboard Form - GRID CARD LAYOUT (Ocean Blue Theme)
 */
public class DashboardForm extends JFrame {
    
    private FertilizerSupplierDAO supplierDAO;
    private ProductDAO productDAO;
    private RetailCustomerDAO customerDAO;
    private SalesOrderDAO orderDAO;
    
    public DashboardForm() {
        supplierDAO = new FertilizerSupplierDAO();
        productDAO = new ProductDAO();
        customerDAO = new RetailCustomerDAO();
        orderDAO = new SalesOrderDAO();
        initComponents();
        loadStatistics();
        setLocationRelativeTo(null);
    }
    
    private void initComponents() {
        setTitle("Fertilizer & Seed Distribution System - Dashboard");
        setSize(1400, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLayout(null);
        getContentPane().setBackground(new Color(236, 240, 241));
        
        // Header Panel - Ocean Blue
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(null);
        headerPanel.setBackground(new Color(41, 128, 185));
        headerPanel.setBounds(0, 0, 1400, 60);
        add(headerPanel);
        
        JLabel lblTitle = new JLabel(" FERTILIZER & SEED DISTRIBUTION - DASHBOARD");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(30, 15, 700, 30);
        headerPanel.add(lblTitle);
        
        // Logout Button
        JButton btnLogout = createHeaderButton(" LOGOUT", 1250, 15);
        btnLogout.addActionListener(e -> logout());
        headerPanel.add(btnLogout);
        
        // Welcome Banner
        JPanel welcomePanel = new JPanel();
        welcomePanel.setLayout(null);
        welcomePanel.setBackground(Color.WHITE);
        welcomePanel.setBounds(30, 80, 1340, 80);
        welcomePanel.setBorder(BorderFactory.createLineBorder(new Color(26, 188, 156), 2));
        add(welcomePanel);
        
        JLabel lblWelcome = new JLabel("Welcome to Agricultural Supply Management");
        lblWelcome.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblWelcome.setForeground(new Color(44, 62, 80));
        lblWelcome.setBounds(30, 15, 700, 25);
        welcomePanel.add(lblWelcome);
        
        JLabel lblSubtext = new JLabel("Manage suppliers, products, customers, and sales orders efficiently");
        lblSubtext.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSubtext.setForeground(new Color(120, 120, 120));
        lblSubtext.setBounds(30, 45, 600, 20);
        welcomePanel.add(lblSubtext);
        
        // GRID CARD LAYOUT - 4 columns x 2 rows
        int cardWidth = 320;
        int cardHeight = 140;
        int startX = 30;
        int startY = 180;
        int gapX = 20;
        int gapY = 20;
        
        // Row 1
        createNavigationCard(" SUPPLIERS", "Manage Fertilizer Suppliers", 
            new Color(41, 128, 185), startX, startY, cardWidth, cardHeight, 
            e -> openSupplierManagement());
        
        createNavigationCard(" PRODUCTS", "Fertilizers & Seeds Inventory", 
            new Color(26, 188, 156), startX + (cardWidth + gapX), startY, cardWidth, cardHeight,
            e -> openProductManagement());
        
        createNavigationCard(" CUSTOMERS", "Retail Customer Management", 
            new Color(52, 152, 219), startX + (cardWidth + gapX) * 2, startY, cardWidth, cardHeight,
            e -> openCustomerManagement());
        
        createNavigationCard(" SALES", "Sales Order Processing", 
            new Color(22, 160, 133), startX + (cardWidth + gapX) * 3, startY, cardWidth, cardHeight,
            e -> openSalesManagement());
        
        // Row 2
        createNavigationCard(" REPORTS", "Generate Sales Reports", 
            new Color(52, 73, 94), startX, startY + cardHeight + gapY, cardWidth, cardHeight,
            e -> generateReport());
        
        createNavigationCard(" ANALYTICS", "View Statistics & Trends", 
            new Color(155, 89, 182), startX + (cardWidth + gapX), startY + cardHeight + gapY, cardWidth, cardHeight,
            e -> showAnalytics());
        
        createNavigationCard(" SETTINGS", "System Configuration", 
            new Color(149, 165, 166), startX + (cardWidth + gapX) * 2, startY + cardHeight + gapY, cardWidth, cardHeight,
            e -> showSettings());
        
        createNavigationCard("🔄 REFRESH", "Reload Dashboard Data", 
            new Color(230, 126, 34), startX + (cardWidth + gapX) * 3, startY + cardHeight + gapY, cardWidth, cardHeight,
            e -> loadStatistics());
        
        // Statistics Panel
        JPanel statsPanel = new JPanel();
        statsPanel.setLayout(null);
        statsPanel.setBackground(Color.WHITE);
        statsPanel.setBounds(30, 500, 1340, 260);
        statsPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(41, 128, 185), 2),
            "System Statistics",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 16),
            new Color(44, 62, 80)
        ));
        add(statsPanel);
        
        // Stat Cards - Horizontal
        createStatDisplay(statsPanel, " Suppliers", "0", new Color(41, 128, 185), 30, 40);
        createStatDisplay(statsPanel, " Products", "0", new Color(26, 188, 156), 365, 40);
        createStatDisplay(statsPanel, " Customers", "0", new Color(52, 152, 219), 700, 40);
        createStatDisplay(statsPanel, " Total Sales", "Rs. 0.00", new Color(22, 160, 133), 1035, 40);
        
        // Quick Info
        JTextArea txtInfo = new JTextArea();
        txtInfo.setEditable(false);
        txtInfo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        txtInfo.setBackground(Color.WHITE);
        txtInfo.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        txtInfo.setText(" Quick Access: Click on any card above to navigate to that section.\n" +
                       " Tip: Use the REFRESH card to update real-time statistics.");
        txtInfo.setBounds(30, 180, 1280, 60);
        statsPanel.add(txtInfo);
    }
    
    private void createNavigationCard(String title, String subtitle, Color color, 
                                     int x, int y, int width, int height, 
                                     java.awt.event.ActionListener action) {
        JPanel card = new JPanel();
        card.setLayout(null);
        card.setBackground(color);
        card.setBounds(x, y, width, height);
        card.setBorder(BorderFactory.createLineBorder(color.darker(), 2));
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        JLabel lblTitle = new JLabel(title, SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(10, 30, width - 20, 35);
        card.add(lblTitle);
        
        JLabel lblSubtitle = new JLabel(subtitle, SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSubtitle.setForeground(new Color(255, 255, 255, 200));
        lblSubtitle.setBounds(10, 75, width - 20, 25);
        card.add(lblSubtitle);
        
        // Hover effect
        card.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                card.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                card.setBackground(color);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (action != null) {
                    action.actionPerformed(null);
                }
            }
        });
        
        add(card);
    }
    
    private void createStatDisplay(JPanel parent, String label, String value, Color color, int x, int y) {
        JPanel statPanel = new JPanel();
        statPanel.setLayout(null);
        statPanel.setBackground(color);
        statPanel.setBounds(x, y, 305, 120);
        statPanel.setBorder(BorderFactory.createLineBorder(color.darker(), 2));
        
        JLabel lblLabel = new JLabel(label, SwingConstants.CENTER);
        lblLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblLabel.setForeground(Color.WHITE);
        lblLabel.setBounds(10, 20, 285, 25);
        statPanel.add(lblLabel);
        
        JLabel lblValue = new JLabel(value, SwingConstants.CENTER);
        lblValue.setFont(new Font("Segoe UI", Font.BOLD, 32));
        lblValue.setForeground(Color.WHITE);
        lblValue.setBounds(10, 55, 285, 45);
        lblValue.setName(label);
        statPanel.add(lblValue);
        
        parent.add(statPanel);
    }
    
    private JButton createHeaderButton(String text, int x, int y) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBounds(x, y, 120, 32);
        btn.setBackground(new Color(231, 76, 60));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
    
    private void loadStatistics() {
        try {
            int totalSuppliers = supplierDAO.getAllSuppliers().size();
            int totalProducts = productDAO.getAllProducts().size();
            int totalCustomers = customerDAO.getAllCustomers().size();
            double totalSales = orderDAO.getTotalSales();
            
            updateStatDisplay(" Suppliers", String.valueOf(totalSuppliers));
            updateStatDisplay(" Products", String.valueOf(totalProducts));
            updateStatDisplay(" Customers", String.valueOf(totalCustomers));
            updateStatDisplay(" Total Sales", "Rs. " + String.format("%.2f", totalSales));
            
            System.out.println("✅ Dashboard statistics loaded!");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error loading statistics: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void updateStatDisplay(String label, String value) {
        Component[] components = getContentPane().getComponents();
        for (Component comp : components) {
            if (comp instanceof JPanel) {
                updateStatDisplayRecursive((JPanel) comp, label, value);
            }
        }
    }
    
    private void updateStatDisplayRecursive(JPanel panel, String label, String value) {
        for (Component comp : panel.getComponents()) {
            if (comp instanceof JPanel) {
                updateStatDisplayRecursive((JPanel) comp, label, value);
            } else if (comp instanceof JLabel) {
                JLabel lbl = (JLabel) comp;
                if (label.equals(lbl.getName())) {
                    lbl.setText(value);
                }
            }
        }
    }
    
    private void openSupplierManagement() {
        SupplierForm supplierForm = new SupplierForm();
        supplierForm.setVisible(true);
    }
    
    private void openProductManagement() {
        ProductForm productForm = new ProductForm();
        productForm.setVisible(true);
    }
    
    private void openCustomerManagement() {
        CustomerForm customerForm = new CustomerForm();
        customerForm.setVisible(true);
    }
    
    private void openSalesManagement() {
        SalesForm salesForm = new SalesForm();
        salesForm.setVisible(true);
    }
    
    private void generateReport() {
        JOptionPane.showMessageDialog(this,
            "📊 Generating Sales Report...\nPlease wait...",
            "Report Generation",
            JOptionPane.INFORMATION_MESSAGE);
        
        ReportController reportController = new ReportController();
        reportController.generateSalesReport();
    }
    
    private void showAnalytics() {
        JOptionPane.showMessageDialog(this,
            "📈 Analytics feature coming soon!",
            "Analytics",
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void showSettings() {
        JOptionPane.showMessageDialog(this,
            "⚙ Settings feature coming soon!",
            "Settings",
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            this.dispose();
            LoginForm loginForm = new LoginForm();
            loginForm.setVisible(true);
        }
    }
    
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> new DashboardForm().setVisible(true));
    }
}