package com.fertilizersystem.controller;

import com.fertilizersystem.dao.DatabaseConnection;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;
import java.sql.Connection;
import javax.swing.JOptionPane;
import java.util.HashMap;
import java.util.Map;

/**
 * Controller for generating Jasper Reports
 */
public class ReportController {
    
    private Connection connection;
    
    public ReportController() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }
    
    /**
     * Generate Sales Report by Product Type
     * Uses 3 tables: sales_orders, products, fertilizer_suppliers
     */
    public void generateSalesReport() {
        try {
            JasperReport jasperReport = createReportDesign();
            
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("ReportTitle", "SALES ANALYSIS BY PRODUCT TYPE");
            parameters.put("GeneratedBy", "Fertilizer & Seed Distribution System");
            
            JasperPrint jasperPrint = JasperFillManager.fillReport(
                jasperReport, 
                parameters, 
                connection
            );
            
            JasperViewer viewer = new JasperViewer(jasperPrint, false);
            viewer.setVisible(true);
            
            System.out.println("✅ Report generated successfully!");
            
        } catch (JRException e) {
            System.err.println("❌ Report generation failed: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, 
                "Report generation failed: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Create Jasper Report Design Programmatically
     */
    private JasperReport createReportDesign() throws JRException {
        String jrxml = 
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<jasperReport xmlns=\"http://jasperreports.sourceforge.net/jasperreports\"\n" +
            "              xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
            "              xsi:schemaLocation=\"http://jasperreports.sourceforge.net/jasperreports\n" +
            "              http://jasperreports.sourceforge.net/xsd/jasperreport.xsd\"\n" +
            "              name=\"SalesReport\" pageWidth=\"595\" pageHeight=\"842\"\n" +
            "              columnWidth=\"535\" leftMargin=\"20\" rightMargin=\"20\"\n" +
            "              topMargin=\"20\" bottomMargin=\"20\">\n" +
            "    \n" +
            "    <parameter name=\"ReportTitle\" class=\"java.lang.String\"/>\n" +
            "    <parameter name=\"GeneratedBy\" class=\"java.lang.String\"/>\n" +
            "    \n" +
            "    <queryString>\n" +
            "        <![CDATA[\n" +
            "            SELECT \n" +
            "                p.product_type,\n" +
            "                p.category,\n" +
            "                COUNT(o.order_id) AS total_orders,\n" +
            "                SUM(o.quantity) AS total_quantity,\n" +
            "                AVG(o.price_per_unit) AS avg_price_per_unit,\n" +
            "                SUM(o.total_amount) AS total_sales,\n" +
            "                s.company_name AS top_supplier\n" +
            "            FROM sales_orders o\n" +
            "            JOIN products p ON o.product_id = p.product_id\n" +
            "            JOIN fertilizer_suppliers s ON p.supplier_id = s.supplier_id\n" +
            "            WHERE o.delivery_status = 'DELIVERED'\n" +
            "            GROUP BY p.product_type, p.category, s.company_name\n" +
            "            ORDER BY total_sales DESC\n" +
            "        ]]>\n" +
            "    </queryString>\n" +
            "    \n" +
            "    <field name=\"product_type\" class=\"java.lang.String\"/>\n" +
            "    <field name=\"category\" class=\"java.lang.String\"/>\n" +
            "    <field name=\"total_orders\" class=\"java.lang.Long\"/>\n" +
            "    <field name=\"total_quantity\" class=\"java.math.BigDecimal\"/>\n" +
            "    <field name=\"avg_price_per_unit\" class=\"java.math.BigDecimal\"/>\n" +
            "    <field name=\"total_sales\" class=\"java.math.BigDecimal\"/>\n" +
            "    <field name=\"top_supplier\" class=\"java.lang.String\"/>\n" +
            "    \n" +
            "    <variable name=\"total_sales_sum\" class=\"java.math.BigDecimal\" calculation=\"Sum\">\n" +
            "        <variableExpression><![CDATA[$F{total_sales}]]></variableExpression>\n" +
            "    </variable>\n" +
            "    \n" +
            "    <title>\n" +
            "        <band height=\"80\">\n" +
            "            <staticText>\n" +
            "                <reportElement x=\"0\" y=\"10\" width=\"535\" height=\"30\"/>\n" +
            "                <textElement textAlignment=\"Center\">\n" +
            "                    <font size=\"18\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <text><![CDATA[FERTILIZER & SEED DISTRIBUTION SYSTEM]]></text>\n" +
            "            </staticText>\n" +
            "            <textField>\n" +
            "                <reportElement x=\"0\" y=\"45\" width=\"535\" height=\"25\"/>\n" +
            "                <textElement textAlignment=\"Center\">\n" +
            "                    <font size=\"14\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <textFieldExpression><![CDATA[$P{ReportTitle}]]></textFieldExpression>\n" +
            "            </textField>\n" +
            "        </band>\n" +
            "    </title>\n" +
            "    \n" +
            "    <columnHeader>\n" +
            "        <band height=\"30\">\n" +
            "            <staticText>\n" +
            "                <reportElement x=\"0\" y=\"0\" width=\"90\" height=\"30\"/>\n" +
            "                <box><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"9\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <text><![CDATA[Product Type]]></text>\n" +
            "            </staticText>\n" +
            "            <staticText>\n" +
            "                <reportElement x=\"90\" y=\"0\" width=\"75\" height=\"30\"/>\n" +
            "                <box><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"9\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <text><![CDATA[Category]]></text>\n" +
            "            </staticText>\n" +
            "            <staticText>\n" +
            "                <reportElement x=\"165\" y=\"0\" width=\"50\" height=\"30\"/>\n" +
            "                <box><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"9\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <text><![CDATA[Orders]]></text>\n" +
            "            </staticText>\n" +
            "            <staticText>\n" +
            "                <reportElement x=\"215\" y=\"0\" width=\"70\" height=\"30\"/>\n" +
            "                <box><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"9\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <text><![CDATA[Quantity]]></text>\n" +
            "            </staticText>\n" +
            "            <staticText>\n" +
            "                <reportElement x=\"285\" y=\"0\" width=\"130\" height=\"30\"/>\n" +
            "                <box><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"9\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <text><![CDATA[Top Supplier]]></text>\n" +
            "            </staticText>\n" +
            "            <staticText>\n" +
            "                <reportElement x=\"415\" y=\"0\" width=\"120\" height=\"30\"/>\n" +
            "                <box><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"9\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <text><![CDATA[Total Sales (Rs)]]></text>\n" +
            "            </staticText>\n" +
            "        </band>\n" +
            "    </columnHeader>\n" +
            "    \n" +
            "    <detail>\n" +
            "        <band height=\"25\">\n" +
            "            <textField>\n" +
            "                <reportElement x=\"0\" y=\"0\" width=\"90\" height=\"25\"/>\n" +
            "                <box leftPadding=\"5\"><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"8\"/>\n" +
            "                </textElement>\n" +
            "                <textFieldExpression><![CDATA[$F{product_type}]]></textFieldExpression>\n" +
            "            </textField>\n" +
            "            <textField>\n" +
            "                <reportElement x=\"90\" y=\"0\" width=\"75\" height=\"25\"/>\n" +
            "                <box leftPadding=\"5\"><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"8\"/>\n" +
            "                </textElement>\n" +
            "                <textFieldExpression><![CDATA[$F{category}]]></textFieldExpression>\n" +
            "            </textField>\n" +
            "            <textField>\n" +
            "                <reportElement x=\"165\" y=\"0\" width=\"50\" height=\"25\"/>\n" +
            "                <box><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"8\"/>\n" +
            "                </textElement>\n" +
            "                <textFieldExpression><![CDATA[$F{total_orders}]]></textFieldExpression>\n" +
            "            </textField>\n" +
            "            <textField pattern=\"#,##0\">\n" +
            "                <reportElement x=\"215\" y=\"0\" width=\"70\" height=\"25\"/>\n" +
            "                <box><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"8\"/>\n" +
            "                </textElement>\n" +
            "                <textFieldExpression><![CDATA[$F{total_quantity}]]></textFieldExpression>\n" +
            "            </textField>\n" +
            "            <textField>\n" +
            "                <reportElement x=\"285\" y=\"0\" width=\"130\" height=\"25\"/>\n" +
            "                <box leftPadding=\"5\"><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"8\"/>\n" +
            "                </textElement>\n" +
            "                <textFieldExpression><![CDATA[$F{top_supplier}]]></textFieldExpression>\n" +
            "            </textField>\n" +
            "            <textField pattern=\"#,##0.00\">\n" +
            "                <reportElement x=\"415\" y=\"0\" width=\"120\" height=\"25\"/>\n" +
            "                <box rightPadding=\"5\"><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Right\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"8\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <textFieldExpression><![CDATA[$F{total_sales}]]></textFieldExpression>\n" +
            "            </textField>\n" +
            "        </band>\n" +
            "    </detail>\n" +
            "    \n" +
            "    <summary>\n" +
            "        <band height=\"50\">\n" +
            "            <staticText>\n" +
            "                <reportElement x=\"215\" y=\"10\" width=\"200\" height=\"30\"/>\n" +
            "                <box><pen lineWidth=\"2.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"12\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <text><![CDATA[GRAND TOTAL (Rs):]]></text>\n" +
            "            </staticText>\n" +
            "            <textField pattern=\"#,##0.00\">\n" +
            "                <reportElement x=\"415\" y=\"10\" width=\"120\" height=\"30\"/>\n" +
            "                <box rightPadding=\"5\"><pen lineWidth=\"2.0\"/></box>\n" +
            "                <textElement textAlignment=\"Right\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"12\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <textFieldExpression><![CDATA[$V{total_sales_sum}]]></textFieldExpression>\n" +
            "            </textField>\n" +
            "        </band>\n" +
            "    </summary>\n" +
            "</jasperReport>";
        
        return JasperCompileManager.compileReport(
            new java.io.ByteArrayInputStream(jrxml.getBytes())
        );
    }
}